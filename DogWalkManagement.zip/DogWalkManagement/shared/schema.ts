import { pgTable, text, serial, integer, boolean, timestamp, foreignKey, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table (both dog owners and dog walkers)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  photo: text("photo"),
  userType: text("user_type", { enum: ["owner", "walker"] }).notNull(),
  phone: text("phone"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Dogs table
export const dogs = pgTable("dogs", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  breed: text("breed").notNull(),
  birthDate: timestamp("birth_date"),
  photo: text("photo"),
  notes: text("notes"),
  ownerId: integer("owner_id").references(() => users.id).notNull(),
  creditBalance: integer("credit_balance").default(0),
  totalSpent: integer("total_spent").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Connections between owners and walkers
export const connections = pgTable("connections", {
  id: serial("id").primaryKey(),
  ownerId: integer("owner_id").references(() => users.id).notNull(),
  walkerId: integer("walker_id").references(() => users.id).notNull(),
  status: text("status", { enum: ["pending", "accepted", "rejected"] }).notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull()
}, (table) => {
  return {
    ownerWalkerUnique: uniqueIndex("owner_walker_unique").on(table.ownerId, table.walkerId)
  };
});

// Dog connections to walkers (through owner)
export const dogWalkerConnections = pgTable("dog_walker_connections", {
  id: serial("id").primaryKey(),
  dogId: integer("dog_id").references(() => dogs.id).notNull(),
  walkerId: integer("walker_id").references(() => users.id).notNull(),
  connectionId: integer("connection_id").references(() => connections.id).notNull(),
  status: text("status", { enum: ["active", "inactive"] }).notNull().default("active"),
  createdAt: timestamp("created_at").defaultNow().notNull()
}, (table) => {
  return {
    dogWalkerUnique: uniqueIndex("dog_walker_unique").on(table.dogId, table.walkerId)
  };
});

// Walks table
export const walks = pgTable("walks", {
  id: serial("id").primaryKey(),
  dogId: integer("dog_id").references(() => dogs.id).notNull(),
  walkerId: integer("walker_id").references(() => users.id).notNull(),
  date: timestamp("date").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  duration: text("duration").notNull(),
  notes: text("notes"),
  behavior: text("behavior"),
  healthNotes: text("health_notes"),
  photo: text("photo"),
  isSpecial: boolean("is_special").default(false).notNull(),
  cost: integer("cost"),
  chargedToDogCredit: boolean("charged_to_dog_credit").default(false),
  status: text("status", { enum: ["scheduled", "completed", "cancelled"] }).notNull().default("scheduled"),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Messages table
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  senderId: integer("sender_id").references(() => users.id).notNull(),
  receiverId: integer("receiver_id").references(() => users.id).notNull(),
  content: text("content").notNull(),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Dog credits transactions
export const dogCredits = pgTable("dog_credits", {
  id: serial("id").primaryKey(),
  dogId: integer("dog_id").references(() => dogs.id).notNull(),
  amount: integer("amount").notNull(),
  description: text("description").notNull(),
  transactionType: text("transaction_type", { enum: ["add", "use"] }).notNull(),
  relatedWalkId: integer("related_walk_id").references(() => walks.id),
  createdAt: timestamp("created_at").defaultNow().notNull()
});

// Insert Schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true
});

export const insertDogSchema = createInsertSchema(dogs).omit({
  id: true,
  createdAt: true
});

export const insertConnectionSchema = createInsertSchema(connections).omit({
  id: true,
  status: true,
  createdAt: true
});

export const insertDogWalkerConnectionSchema = createInsertSchema(dogWalkerConnections).omit({
  id: true,
  status: true,
  createdAt: true
});

export const insertWalkSchema = createInsertSchema(walks).omit({
  id: true,
  createdAt: true,
  status: true,
  isSpecial: true
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
  read: true,
  createdAt: true
});

export const insertDogCreditSchema = createInsertSchema(dogCredits).omit({
  id: true,
  createdAt: true
});

// Login schemas
export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6)
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Dog = typeof dogs.$inferSelect;
export type InsertDog = z.infer<typeof insertDogSchema>;
export type Connection = typeof connections.$inferSelect;
export type InsertConnection = z.infer<typeof insertConnectionSchema>;
export type DogWalkerConnection = typeof dogWalkerConnections.$inferSelect;
export type InsertDogWalkerConnection = z.infer<typeof insertDogWalkerConnectionSchema>;
export type Walk = typeof walks.$inferSelect;
export type InsertWalk = z.infer<typeof insertWalkSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type DogCredit = typeof dogCredits.$inferSelect;
export type InsertDogCredit = z.infer<typeof insertDogCreditSchema>;
export type Login = z.infer<typeof loginSchema>;
