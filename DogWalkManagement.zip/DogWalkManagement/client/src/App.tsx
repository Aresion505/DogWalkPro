import { Switch, Route, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import DogsIndex from "@/pages/dogs/index";
import AddDog from "@/pages/dogs/add-dog";
import WalksIndex from "@/pages/walks/index";
import ConnectionsIndex from "@/pages/connections/index";
import FinanceIndex from "@/pages/finance/index";
import Profile from "@/pages/profile";
import { AuthProvider } from "./context/auth-context";
import { Sidebar } from "./components/layout/sidebar";
import { MobileNav } from "./components/layout/mobile-nav";

function ProtectedRoutes() {
  const [location] = useLocation();
  
  // Skip layout for auth pages
  if (location === "/login" || location === "/register") {
    return (
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/register" component={Register} />
        <Route component={NotFound} />
      </Switch>
    );
  }

  return (
    <div className="flex min-h-screen bg-neutral-50">
      <Sidebar />
      
      <main className="flex-1 flex flex-col">
        <div className="flex-1 relative">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/dogs" component={DogsIndex} />
            <Route path="/dogs/add" component={AddDog} />
            <Route path="/walks" component={WalksIndex} />
            <Route path="/connections" component={ConnectionsIndex} />
            <Route path="/finance" component={FinanceIndex} />
            <Route path="/profile" component={Profile} />
            <Route component={NotFound} />
          </Switch>
        </div>
        
        <MobileNav />
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ProtectedRoutes />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
