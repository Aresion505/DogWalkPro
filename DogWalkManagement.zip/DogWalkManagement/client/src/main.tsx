import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add meta tags for SEO and mobile responsiveness
const meta = document.createElement('meta');
meta.name = 'description';
meta.content = 'DogWalkPro - Connect dog owners with dog walkers and track your pets walks';
document.head.appendChild(meta);

const title = document.createElement('title');
title.textContent = 'DogWalkPro';
document.head.appendChild(title);

// Create favicon
const favicon = document.createElement('link');
favicon.rel = 'icon';
favicon.href = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><text y=".9em" font-size="90">🐾</text></svg>';
document.head.appendChild(favicon);

createRoot(document.getElementById("root")!).render(<App />);
