import { useEffect } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/context/auth-context";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Dog, Camera } from "lucide-react";
import { Link } from "wouter";

// Dog breed list
const dogBreeds = [
  "Affenpinscher", "Afghan Hound", "Airedale Terrier", "Akita", "Alaskan Malamute", "American Bulldog",
  "American Eskimo Dog", "American Foxhound", "American Pit Bull Terrier", "American Staffordshire Terrier",
  "Australian Cattle Dog", "Australian Shepherd", "Australian Terrier", "Basenji", "Basset Hound", 
  "Beagle", "Bearded Collie", "Beauceron", "Bedlington Terrier", "Belgian Malinois", "Belgian Sheepdog",
  "Belgian Tervuren", "Bernese Mountain Dog", "Bichon Frise", "Black and Tan Coonhound", "Black Russian Terrier",
  "Bloodhound", "Border Collie", "Border Terrier", "Borzoi", "Boston Terrier", "Bouvier des Flandres",
  "Boxer", "Boykin Spaniel", "Briard", "Brittany", "Brussels Griffon", "Bull Terrier", "Bulldog", "Bullmastiff",
  "Cairn Terrier", "Canaan Dog", "Cane Corso", "Cardigan Welsh Corgi", "Cavalier King Charles Spaniel",
  "Chesapeake Bay Retriever", "Chihuahua", "Chinese Crested", "Chinese Shar-Pei", "Chow Chow", "Clumber Spaniel",
  "Cocker Spaniel", "Collie", "Curly-Coated Retriever", "Dachshund", "Dalmatian", "Dandie Dinmont Terrier",
  "Doberman Pinscher", "Dogue de Bordeaux", "English Cocker Spaniel", "English Foxhound", "English Setter",
  "English Springer Spaniel", "English Toy Spaniel", "Flat-Coated Retriever", "French Bulldog", "German Pinscher",
  "German Shepherd Dog", "German Shorthaired Pointer", "German Wirehaired Pointer", "Giant Schnauzer",
  "Golden Retriever", "Gordon Setter", "Great Dane", "Great Pyrenees", "Greater Swiss Mountain Dog",
  "Greyhound", "Havanese", "Irish Setter", "Irish Terrier", "Irish Water Spaniel", "Irish Wolfhound",
  "Italian Greyhound", "Jack Russell Terrier", "Japanese Chin", "Keeshond", "Kerry Blue Terrier", "Komondor",
  "Kuvasz", "Labrador Retriever", "Lakeland Terrier", "Lhasa Apso", "Maltese", "Manchester Terrier",
  "Mastiff", "Miniature Pinscher", "Miniature Schnauzer", "Mixed Breed", "Neapolitan Mastiff", "Newfoundland",
  "Norfolk Terrier", "Norwegian Elkhound", "Norwich Terrier", "Nova Scotia Duck Tolling Retriever",
  "Old English Sheepdog", "Otterhound", "Papillon", "Pekingese", "Pembroke Welsh Corgi", "Petit Basset Griffon Vendeen",
  "Pharaoh Hound", "Plott Hound", "Pointer", "Polish Lowland Sheepdog", "Pomeranian", "Poodle", "Portuguese Water Dog",
  "Pug", "Puli", "Rhodesian Ridgeback", "Rottweiler", "Saint Bernard", "Saluki", "Samoyed", "Schipperke",
  "Scottish Deerhound", "Scottish Terrier", "Sealyham Terrier", "Shetland Sheepdog", "Shiba Inu", "Shih Tzu",
  "Siberian Husky", "Silky Terrier", "Skye Terrier", "Smooth Fox Terrier", "Soft Coated Wheaten Terrier",
  "Staffordshire Bull Terrier", "Standard Schnauzer", "Sussex Spaniel", "Swedish Vallhund", "Tibetan Mastiff",
  "Tibetan Spaniel", "Tibetan Terrier", "Toy Fox Terrier", "Vizsla", "Weimaraner", "Welsh Springer Spaniel",
  "Welsh Terrier", "West Highland White Terrier", "Whippet", "Wire Fox Terrier", "Wirehaired Pointing Griffon",
  "Yorkshire Terrier"
];

// Dog form schema
const dogSchema = z.object({
  name: z.string().min(2, "Name must have at least 2 characters"),
  breed: z.string().min(2, "Please select a breed"),
  birthDate: z.string().optional(),
  notes: z.string().optional(),
  photo: z.string().optional(),
});

type DogFormValues = z.infer<typeof dogSchema>;

export default function AddDog() {
  const [location, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Redirect to login if no user or if user is not an owner
  useEffect(() => {
    if (!loading && (!user || user.userType !== "owner")) {
      setLocation(user ? "/" : "/login");
    }
  }, [user, loading, setLocation]);

  // Form setup
  const form = useForm<DogFormValues>({
    resolver: zodResolver(dogSchema),
    defaultValues: {
      name: "",
      breed: "",
      birthDate: "",
      notes: "",
      photo: "",
    },
  });

  // Dog creation mutation
  const createDogMutation = useMutation({
    mutationFn: async (data: DogFormValues) => {
      const res = await apiRequest("POST", "/api/dogs", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Dog added successfully!",
        description: "The new dog has been added to your list.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      setLocation("/dogs");
    },
    onError: (error: any) => {
      toast({
        title: "Error adding dog",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  // Form submission
  const onSubmit = (values: DogFormValues) => {
    if (!user) return;
    createDogMutation.mutate(values);
  };

  if (loading || !user || user.userType !== "owner") {
    return (
      <div className="p-4 flex justify-center items-center min-h-screen">
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <section className="p-4 flex-1 overflow-auto">
      <div className="max-w-2xl mx-auto">
        <div className="mb-6">
          <Link href="/dogs">
            <a className="flex items-center text-gray-500 hover:text-gray-700 mb-4">
              <ArrowLeft className="h-4 w-4 mr-1" /> Back to dogs
            </a>
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Add New Dog</h1>
          <p className="text-gray-500">Fill in your dog's information</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Dog className="h-5 w-5 mr-2" /> Dog Information
            </CardTitle>
            <CardDescription>
              Provide basic information about your dog so dog walkers can get to know them better
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dog's Name</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="E.g.: Rex" 
                          {...field} 
                          disabled={createDogMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="breed"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Breed</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        disabled={createDogMutation.isPending}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a breed" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="max-h-80">
                          {dogBreeds.map((breed) => (
                            <SelectItem key={breed} value={breed}>
                              {breed}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="birthDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Birth Date (optional)</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field} 
                          disabled={createDogMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes (optional)</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Additional information about your dog, such as behavior, preferences, special needs, etc." 
                          {...field} 
                          rows={4}
                          disabled={createDogMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="photo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dog Photo (optional)</FormLabel>
                      <FormControl>
                        <div className="flex flex-col gap-2">
                          <Input 
                            type="url"
                            placeholder="Enter a URL for your dog's photo" 
                            {...field} 
                            disabled={createDogMutation.isPending}
                          />
                          {field.value && (
                            <div className="mt-2 border rounded-md p-2 w-full overflow-hidden">
                              <div className="text-sm font-medium mb-2">Preview:</div>
                              <img 
                                src={field.value} 
                                alt="Dog preview" 
                                className="w-32 h-32 object-cover rounded-md" 
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src = "https://placehold.co/200x200?text=No+Image";
                                }}
                              />
                            </div>
                          )}
                        </div>
                      </FormControl>
                      <FormDescription>
                        <span className="flex items-center gap-1"><Camera className="h-3 w-3" /> Enter a valid image URL for your dog's photo</span>
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </form>
            </Form>
          </CardContent>
          <CardFooter className="flex justify-end space-x-2">
            <Button
              variant="outline"
              onClick={() => setLocation("/dogs")}
              disabled={createDogMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              onClick={form.handleSubmit(onSubmit)}
              disabled={createDogMutation.isPending}
            >
              {createDogMutation.isPending ? "Adding..." : "Add Dog"}
            </Button>
          </CardFooter>
        </Card>
      </div>
    </section>
  );
}
