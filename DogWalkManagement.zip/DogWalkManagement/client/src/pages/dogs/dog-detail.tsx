import { useEffect, useState } from "react";
import { useLocation, useParams, Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { format, parseISO } from "date-fns";
import { enUS } from "date-fns/locale";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  ArrowLeft, 
  CalendarDays, 
  Clock, 
  DollarSign, 
  FileText, 
  PawPrint,
  Plus,
  BarChart3
} from "lucide-react";
import { DogReportDashboard } from "@/components/dog-report-dashboard";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { AvatarWithFallback } from "@/components/ui/avatar-with-fallback";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

// Report form schema
const reportSchema = z.object({
  notes: z.string().min(10, "Notes should be at least 10 characters"),
  behavior: z.string().min(5, "Behavior description is required"),
  healthNotes: z.string().optional(),
  photo: z.string().optional(),
});

// Credit form schema
const creditSchema = z.object({
  amount: z.string().refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: "Amount must be a positive number",
  }),
  description: z.string().min(3, "Description is required"),
});

// Walk report component
const WalkReport = ({ walk, onUpdateReport }: { walk: any, onUpdateReport?: () => void }) => {
  const [showReportDialog, setShowReportDialog] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Form setup
  const form = useForm({
    resolver: zodResolver(reportSchema),
    defaultValues: {
      notes: walk.notes || "",
      behavior: walk.behavior || "",
      healthNotes: walk.healthNotes || "",
      photo: walk.photo || "",
    },
  });
  
  // Report update mutation
  const reportMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("PATCH", `/api/walks/${walk.id}/report`, data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Report updated",
        description: "Walk report has been successfully updated",
      });
      
      queryClient.invalidateQueries({ queryKey: [`/api/dogs/${walk.dogId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/walks"] });
      
      if (onUpdateReport) {
        onUpdateReport();
      }
      
      setShowReportDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error updating report",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });
  
  // Submit handler
  const onSubmit = (data: any) => {
    reportMutation.mutate(data);
  };
  
  return (
    <Card className="mb-4">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <CalendarDays className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-sm font-medium">
              {format(new Date(walk.date), "EEEE, MMMM dd, yyyy", { locale: enUS })}
            </CardTitle>
          </div>
          <Badge 
            variant={
              walk.status === "completed" 
                ? "success" 
                : walk.status === "cancelled" 
                  ? "destructive" 
                  : "outline"
            }
          >
            {walk.status === "completed" 
              ? "Completed" 
              : walk.status === "cancelled" 
                ? "Cancelled" 
                : "Scheduled"}
          </Badge>
        </div>
        <CardDescription className="flex items-center gap-2">
          <Clock className="h-3 w-3" />
          {walk.formattedStartTime} - {walk.formattedEndTime} ({walk.duration})
        </CardDescription>
      </CardHeader>
      
      <CardContent>
        {walk.notes ? (
          <div className="space-y-2">
            <div>
              <h4 className="text-sm font-medium">Notes:</h4>
              <p className="text-sm text-muted-foreground">{walk.notes}</p>
            </div>
            
            {walk.behavior && (
              <div>
                <h4 className="text-sm font-medium">Behavior:</h4>
                <p className="text-sm text-muted-foreground">{walk.behavior}</p>
              </div>
            )}
            
            {walk.healthNotes && (
              <div>
                <h4 className="text-sm font-medium">Health:</h4>
                <p className="text-sm text-muted-foreground">{walk.healthNotes}</p>
              </div>
            )}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground italic">
            {walk.status === "completed" 
              ? "No report available for this walk" 
              : "Report will be available after the walk is completed"}
          </p>
        )}
      </CardContent>
      
      <CardFooter className="pt-0">
        <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
          <DialogTrigger asChild>
            <Button 
              variant="outline" 
              size="sm"
              disabled={walk.status !== "completed"}
            >
              <FileText className="h-4 w-4 mr-2" />
              {walk.notes ? "Update Report" : "Add Report"}
            </Button>
          </DialogTrigger>
          
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Walk Report</DialogTitle>
              <DialogDescription>
                Add details about the walk with {walk.dog?.name} on {format(new Date(walk.date), "MMM dd, yyyy")}
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Walk Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="How was the walk? Describe the route, activities, etc."
                          {...field}
                          rows={3}
                          disabled={reportMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="behavior"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dog's Behavior</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="How did the dog behave during the walk?"
                          {...field}
                          rows={2}
                          disabled={reportMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="healthNotes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Health Notes (Optional)</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Any health observations? Eating, drinking, bathroom breaks, etc."
                          {...field}
                          rows={2}
                          disabled={reportMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="photo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Photo URL (Optional)</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="URL to a photo from the walk"
                          {...field}
                          disabled={reportMutation.isPending}
                        />
                      </FormControl>
                      <FormDescription>
                        Add a link to a photo from the walk
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowReportDialog(false)}
                    disabled={reportMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={reportMutation.isPending}
                  >
                    {reportMutation.isPending ? "Saving..." : "Save Report"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </CardFooter>
    </Card>
  );
};

// Credit management component
const DogCredit = ({ dog, refetchDog }: { dog: any, refetchDog: () => void }) => {
  const [showCreditDialog, setShowCreditDialog] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Form setup
  const form = useForm({
    resolver: zodResolver(creditSchema),
    defaultValues: {
      amount: "",
      description: "",
    },
  });
  
  // Credit mutation
  const creditMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", `/api/dogs/${dog.id}/credit`, {
        ...data,
        amount: parseFloat(data.amount),
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Credit added",
        description: `Credit has been added to ${dog.name}'s account`,
      });
      
      queryClient.invalidateQueries({ queryKey: [`/api/dogs/${dog.id}`] });
      refetchDog();
      setShowCreditDialog(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error adding credit",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });
  
  // Submit handler
  const onSubmit = (data: any) => {
    creditMutation.mutate(data);
  };
  
  // Only owner should see this
  if (user?.userType !== "owner") return null;
  
  return (
    <div className="mb-6">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-lg font-medium">Dog Credits</h3>
        <Dialog open={showCreditDialog} onOpenChange={setShowCreditDialog}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" /> Add Credit
            </Button>
          </DialogTrigger>
          
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Credit for {dog.name}</DialogTitle>
              <DialogDescription>
                Add credit for future walks and other services
              </DialogDescription>
            </DialogHeader>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <DollarSign className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                          <Input 
                            type="number"
                            placeholder="0.00"
                            className="pl-8"
                            step="0.01"
                            min="0.01"
                            {...field}
                            disabled={creditMutation.isPending}
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="Walk package, special care, etc."
                          {...field}
                          disabled={creditMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <DialogFooter>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => setShowCreditDialog(false)}
                    disabled={creditMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={creditMutation.isPending}
                  >
                    {creditMutation.isPending ? "Adding..." : "Add Credit"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="text-sm text-muted-foreground">Current Balance</p>
              <p className="text-xl font-semibold">${dog.creditBalance || 0}</p>
            </div>
            
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Total Spent</p>
              <p className="text-lg">${dog.totalSpent || 0}</p>
            </div>
          </div>
          
          {dog.creditHistory && dog.creditHistory.length > 0 ? (
            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">Recent Transactions</h4>
              <div className="space-y-2">
                {dog.creditHistory.slice(0, 3).map((transaction: any, index: number) => (
                  <div key={index} className="flex justify-between text-sm">
                    <span>{transaction.description}</span>
                    <span className={transaction.amount > 0 ? "text-green-600" : "text-red-600"}>
                      {transaction.amount > 0 ? "+" : ""}{transaction.amount}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground mt-4 italic">No transactions yet</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default function DogDetail() {
  const params = useParams<{ id: string }>();
  const [location, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("walks");
  const dogId = parseInt(params.id);
  
  // Redirect if not logged in
  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    }
  }, [user, loading, setLocation]);
  
  // Fetch dog details
  const { 
    data: dogData, 
    isLoading: loadingDog,
    refetch: refetchDog
  } = useQuery({
    queryKey: [`/api/dogs/${dogId}`],
    enabled: !!user && !isNaN(dogId),
  });
  
  // Fetch dog walks
  const { data: walksData, isLoading: loadingWalks } = useQuery({
    queryKey: [`/api/dogs/${dogId}/walks`],
    enabled: !!user && !isNaN(dogId),
  });
  
  if (loading || loadingDog) {
    return (
      <div className="p-4 flex justify-center items-center min-h-screen">
        <p>Loading...</p>
      </div>
    );
  }
  
  if (!dogData?.dog) {
    return (
      <div className="p-4">
        <Link href="/dogs">
          <a className="text-blue-500 flex items-center mb-4">
            <ArrowLeft className="h-4 w-4 mr-1" /> Back to dogs
          </a>
        </Link>
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Dog not found</h2>
          <p className="text-gray-500 mb-6">The requested dog could not be found</p>
          <Button asChild>
            <Link href="/dogs">
              <a>Return to Dogs</a>
            </Link>
          </Button>
        </div>
      </div>
    );
  }
  
  const dog = dogData.dog;
  const walks = walksData?.walks || [];
  
  // Group walks by status
  const completedWalks = walks.filter((walk: any) => walk.status === "completed")
    .sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  const scheduledWalks = walks.filter((walk: any) => walk.status === "scheduled")
    .sort((a: any, b: any) => new Date(a.date).getTime() - new Date(b.date).getTime());
  
  const cancelledWalks = walks.filter((walk: any) => walk.status === "cancelled")
    .sort((a: any, b: any) => new Date(b.date).getTime() - new Date(a.date).getTime());
  
  return (
    <section className="p-4 pb-20 md:pb-4 flex-1 overflow-auto">
      <Link href="/dogs">
        <a className="flex items-center text-gray-500 hover:text-gray-700 mb-4">
          <ArrowLeft className="h-4 w-4 mr-1" /> Back to dogs
        </a>
      </Link>
      
      <div className="flex flex-col md:flex-row items-start gap-6">
        {/* Dog info */}
        <div className="w-full md:w-1/3">
          <Card>
            <CardHeader className="pb-2">
              <div className="flex items-center gap-4">
                <AvatarWithFallback
                  src={dog.photo}
                  fallback={dog.name.charAt(0)}
                  className="h-16 w-16"
                />
                <div>
                  <CardTitle className="text-xl">{dog.name}</CardTitle>
                  <CardDescription>{dog.breed}</CardDescription>
                </div>
              </div>
            </CardHeader>
            
            <CardContent>
              <div className="space-y-2">
                {dog.birthDate && (
                  <div className="flex items-center text-sm">
                    <CalendarDays className="h-4 w-4 mr-2 text-muted-foreground" />
                    <span>
                      Born: {format(new Date(dog.birthDate), "MMMM d, yyyy", { locale: enUS })}
                    </span>
                  </div>
                )}
                
                <div className="flex items-center text-sm">
                  <PawPrint className="h-4 w-4 mr-2 text-muted-foreground" />
                  <span>Total walks: {completedWalks.length}</span>
                </div>
              </div>
              
              {dog.notes && (
                <>
                  <Separator className="my-4" />
                  <div>
                    <h3 className="text-sm font-medium mb-1">Notes</h3>
                    <p className="text-sm text-muted-foreground">{dog.notes}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
          
          {/* Credit management */}
          <DogCredit dog={dog} refetchDog={refetchDog} />
        </div>
        
        {/* Tabs for walks and reports */}
        <div className="w-full md:w-2/3">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="walks">All Walks</TabsTrigger>
              <TabsTrigger value="reports">Reports</TabsTrigger>
              <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            </TabsList>
            
            {/* All Walks Tab */}
            <TabsContent value="walks" className="space-y-4">
              {loadingWalks ? (
                <div className="flex justify-center items-center p-12">
                  <p className="text-gray-500">Loading walks...</p>
                </div>
              ) : walks.length > 0 ? (
                <div className="space-y-4">
                  {completedWalks.map((walk: any) => (
                    <WalkReport key={walk.id} walk={walk} onUpdateReport={refetchDog} />
                  ))}
                  
                  {scheduledWalks.length > 0 && (
                    <>
                      <h3 className="text-lg font-medium mt-8">Scheduled Walks</h3>
                      <div className="space-y-4">
                        {scheduledWalks.map((walk: any) => (
                          <WalkReport key={walk.id} walk={walk} onUpdateReport={refetchDog} />
                        ))}
                      </div>
                    </>
                  )}
                  
                  {cancelledWalks.length > 0 && (
                    <>
                      <h3 className="text-lg font-medium mt-8">Cancelled Walks</h3>
                      <div className="space-y-4">
                        {cancelledWalks.map((walk: any) => (
                          <WalkReport key={walk.id} walk={walk} onUpdateReport={refetchDog} />
                        ))}
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="text-center p-12">
                  <div className="mb-4 text-gray-400">
                    <PawPrint className="h-16 w-16 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No walks recorded yet
                  </h3>
                  <p className="text-gray-500 mb-6 max-w-md mx-auto">
                    {user?.userType === "walker" 
                      ? `Start recording walks with ${dog.name} to build a history`
                      : `${dog.name} hasn't gone on any walks yet`}
                  </p>
                </div>
              )}
            </TabsContent>
            
            {/* Reports Tab */}
            <TabsContent value="reports" className="space-y-4">
              {loadingWalks ? (
                <div className="flex justify-center items-center p-12">
                  <p className="text-gray-500">Loading reports...</p>
                </div>
              ) : completedWalks.filter((walk: any) => walk.notes).length > 0 ? (
                <div className="space-y-4">
                  {completedWalks
                    .filter((walk: any) => walk.notes)
                    .map((walk: any) => (
                      <WalkReport key={walk.id} walk={walk} onUpdateReport={refetchDog} />
                    ))}
                </div>
              ) : (
                <div className="text-center p-12">
                  <div className="mb-4 text-gray-400">
                    <FileText className="h-16 w-16 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No reports available
                  </h3>
                  <p className="text-gray-500 mb-6 max-w-md mx-auto">
                    Reports will be available after walks are completed and documented
                  </p>
                </div>
              )}
            </TabsContent>
            
            {/* Scheduled Tab */}
            <TabsContent value="scheduled" className="space-y-4">
              {loadingWalks ? (
                <div className="flex justify-center items-center p-12">
                  <p className="text-gray-500">Loading scheduled walks...</p>
                </div>
              ) : scheduledWalks.length > 0 ? (
                <div className="space-y-4">
                  {scheduledWalks.map((walk: any) => (
                    <WalkReport key={walk.id} walk={walk} onUpdateReport={refetchDog} />
                  ))}
                </div>
              ) : (
                <div className="text-center p-12">
                  <div className="mb-4 text-gray-400">
                    <CalendarDays className="h-16 w-16 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No scheduled walks
                  </h3>
                  <p className="text-gray-500 mb-6 max-w-md mx-auto">
                    {user?.userType === "walker" 
                      ? `Schedule walks with ${dog.name}`
                      : `${dog.name} doesn't have any upcoming walks`}
                  </p>
                </div>
              )}
            </TabsContent>
            
            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-4">
              {loadingWalks ? (
                <div className="flex justify-center items-center p-12">
                  <p className="text-gray-500">Loading dashboard data...</p>
                </div>
              ) : walks.length > 0 ? (
                <DogReportDashboard dog={dog} walks={walks} />
              ) : (
                <div className="text-center p-12">
                  <div className="mb-4 text-gray-400">
                    <BarChart3 className="h-16 w-16 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No data for reports
                  </h3>
                  <p className="text-gray-500 mb-6 max-w-md mx-auto">
                    Complete some walks with {dog.name} to see analytics and reports
                  </p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </section>
  );
}