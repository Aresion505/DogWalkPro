import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { DogCard } from "@/components/dog-card";
import { Plus } from "lucide-react";

export default function DogsIndex() {
  const [_, setLocation] = useLocation();
  const { user, loading } = useAuth();

  // Redirect to login if no user
  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    }
  }, [user, loading, setLocation]);

  // Fetch dogs
  const { data: dogsData, isLoading: loadingDogs } = useQuery({
    queryKey: ["/api/dogs"],
    enabled: !!user,
  });

  // Fetch walks for walk count (optional)
  const { data: walksData } = useQuery({
    queryKey: ["/api/walks"],
    enabled: !!user,
  });

  if (loading || !user) {
    return (
      <div className="p-4 flex justify-center items-center min-h-screen">
        <p>Loading...</p>
      </div>
    );
  }

  // Calculate walk counts for each dog if walks data is available
  const dogsWithWalkCount = dogsData?.dogs?.map((dog: any) => {
    if (walksData?.walks) {
      const walkCount = walksData.walks.filter((walk: any) => walk.dogId === dog.id).length;
      return { ...dog, walkCount };
    }
    return dog;
  }) || [];

  return (
    <section className="p-4 pb-20 md:pb-4 flex-1 overflow-auto">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">Dogs</h1>
          <p className="text-gray-500">
            {user.userType === "owner" 
              ? "Manage your dogs" 
              : "Dogs connected with you"}
          </p>
        </div>
        
        {user.userType === "owner" && (
          <Button asChild>
            <Link href="/dogs/add">
              <a className="flex items-center">
                <Plus className="h-4 w-4 mr-2" /> New dog
              </a>
            </Link>
          </Button>
        )}
      </header>
      
      {loadingDogs ? (
        <div className="flex justify-center items-center p-12">
          <p className="text-gray-500">Loading...</p>
        </div>
      ) : dogsWithWalkCount.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {dogsWithWalkCount.map((dog: any) => (
            <DogCard key={dog.id} dog={dog} walkCount={dog.walkCount || 0} />
          ))}
          
          {user.userType === "owner" && (
            <Card className="border-2 border-dashed border-gray-300 flex flex-col items-center justify-center p-4 h-48">
              <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 mb-2">
                <Plus className="h-6 w-6" />
              </div>
              <Link href="/dogs/add">
                <a className="text-gray-500 text-center hover:text-gray-700">
                  Add new dog
                </a>
              </Link>
            </Card>
          )}
        </div>
      ) : (
        <div className="text-center p-12">
          <div className="mb-4 text-gray-400">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-16 h-16 mx-auto"
            >
              <path d="M10 5.172C10 3.12 12.507 2 14.444 2c1.938 0 3.556.988 3.556 3.348 0 1.777-1.325 3.464-2.74 5.089-.191.22-.379.435-.562.645-.947 1.086-1.798 2.063-1.798 2.727M4.684 15c-.664-1.618-.984-3.3-.984-5 0-2.21 1.817-4 4.096-4 1.72 0 3.395 2 3.774 4.145" />
              <path d="M21.048 14c.345.6.552 1.284.552 2 0 2.21-1.817 4-4.096 4s-4.096-1.79-4.096-4 1.817-4 4.096-4c.596 0 1.164.121 1.679.341" />
              <path d="M10.236 18c.346.6.553 1.284.553 2 0 2.21-1.848 4-4.127 4-2.28 0-4.127-1.79-4.127-4s1.848-4 4.127-4c.596 0 1.164.121 1.679.341" />
            </svg>
          </div>
          
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            {user.userType === "owner" 
              ? "You don't have any dogs registered yet" 
              : "You are not connected to any dogs yet"}
          </h3>
          
          <p className="text-gray-500 mb-6 max-w-md mx-auto">
            {user.userType === "owner"
              ? "Add your dogs to connect them with dog walkers"
              : "Connect with dog owners to start recording walks"}
          </p>
          
          {user.userType === "owner" ? (
            <Button asChild>
              <Link href="/dogs/add">
                <a>Add a dog</a>
              </Link>
            </Button>
          ) : (
            <Button asChild>
              <Link href="/connections">
                <a>Manage connections</a>
              </Link>
            </Button>
          )}
        </div>
      )}
    </section>
  );
}
