import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { WalkItem } from "@/components/walk-item";
import { WalkForm } from "@/components/walk-form";
import { Calendar } from "lucide-react";
import { format, parseISO } from "date-fns";
import { enUS } from "date-fns/locale";

export default function WalksIndex() {
  const [_, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState("upcoming");

  // Redirect to login if no user
  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    }
  }, [user, loading, setLocation]);

  // Fetch walks
  const { data: walksData, isLoading: loadingWalks } = useQuery({
    queryKey: ["/api/walks"],
    enabled: !!user,
  });

  // Fetch scheduled walks
  const { data: scheduledWalksData, isLoading: loadingScheduled } = useQuery({
    queryKey: ["/api/walks/scheduled"],
    enabled: !!user,
  });

  if (loading || !user) {
    return (
      <div className="p-4 flex justify-center items-center min-h-screen">
        <p>Loading...</p>
      </div>
    );
  }

  // Filter and sort walks for different tabs
  const upcomingWalks = scheduledWalksData?.walks || [];
  
  const completedWalks = walksData?.walks?.filter((walk: any) => 
    walk.status === "completed"
  ).sort((a: any, b: any) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  ) || [];
  
  const cancelledWalks = walksData?.walks?.filter((walk: any) => 
    walk.status === "cancelled"
  ).sort((a: any, b: any) => 
    new Date(b.date).getTime() - new Date(a.date).getTime()
  ) || [];

  // Group walks by date
  const groupWalksByDate = (walks: any[]) => {
    return walks.reduce((groups: any, walk: any) => {
      const date = format(new Date(walk.date), 'yyyy-MM-dd');
      if (!groups[date]) {
        groups[date] = [];
      }
      groups[date].push(walk);
      return groups;
    }, {});
  };

  const upcomingWalksByDate = groupWalksByDate(upcomingWalks);
  const completedWalksByDate = groupWalksByDate(completedWalks);
  const cancelledWalksByDate = groupWalksByDate(cancelledWalks);

  return (
    <section className="p-4 pb-20 md:pb-4 flex-1 overflow-auto">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">Walks</h1>
        <p className="text-gray-500">
          {user.userType === "walker" 
            ? "Manage dog walks" 
            : "Track your dogs' walks"}
        </p>
      </header>
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upcoming">Scheduled</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="cancelled">Cancelled</TabsTrigger>
        </TabsList>
        
        <TabsContent value="upcoming" className="space-y-4">
          {loadingScheduled ? (
            <div className="flex justify-center items-center p-12">
              <p className="text-gray-500">Loading...</p>
            </div>
          ) : Object.keys(upcomingWalksByDate).length > 0 ? (
            Object.entries(upcomingWalksByDate).map(([date, walks]: [string, any]) => (
              <Card key={date} className="overflow-hidden shadow-sm">
                <CardHeader className="py-3">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                    {format(parseISO(date), "EEEE, MMMM dd", { locale: enUS })}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {walks.map((walk: any) => (
                    <WalkItem key={walk.id} walk={walk} />
                  ))}
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center p-12">
              <div className="mb-4 text-gray-400">
                <Calendar className="h-16 w-16 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No scheduled walks
              </h3>
              <p className="text-gray-500 mb-6 max-w-md mx-auto">
                {user.userType === "walker" 
                  ? "Register new walks using the button below"
                  : "Contact a dog walker to schedule walks"}
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="completed" className="space-y-4">
          {loadingWalks ? (
            <div className="flex justify-center items-center p-12">
              <p className="text-gray-500">Loading...</p>
            </div>
          ) : Object.keys(completedWalksByDate).length > 0 ? (
            Object.entries(completedWalksByDate).map(([date, walks]: [string, any]) => (
              <Card key={date} className="overflow-hidden shadow-sm">
                <CardHeader className="py-3">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                    {format(parseISO(date), "EEEE, MMMM dd", { locale: enUS })}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {walks.map((walk: any) => (
                    <WalkItem key={walk.id} walk={walk} />
                  ))}
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center p-12">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No completed walks
              </h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Completed walks will appear here
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="cancelled" className="space-y-4">
          {loadingWalks ? (
            <div className="flex justify-center items-center p-12">
              <p className="text-gray-500">Loading...</p>
            </div>
          ) : Object.keys(cancelledWalksByDate).length > 0 ? (
            Object.entries(cancelledWalksByDate).map(([date, walks]: [string, any]) => (
              <Card key={date} className="overflow-hidden shadow-sm">
                <CardHeader className="py-3">
                  <CardTitle className="text-sm font-medium flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                    {format(parseISO(date), "EEEE, MMMM dd", { locale: enUS })}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  {walks.map((walk: any) => (
                    <WalkItem key={walk.id} walk={walk} />
                  ))}
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center p-12">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No cancelled walks
              </h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Cancelled walks will appear here
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Register Walk Button and Form (for walkers only) */}
      {user.userType === "walker" && <WalkForm />}
    </section>
  );
}
