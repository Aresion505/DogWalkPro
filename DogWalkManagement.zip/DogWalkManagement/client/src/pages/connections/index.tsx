import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { AvatarWithFallback } from "@/components/ui/avatar-with-fallback";
import { Check, X, UserPlus, UserCheck, Users, Mail } from "lucide-react";

export default function ConnectionsIndex() {
  const [_, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  // Redirect to login if no user
  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    }
  }, [user, loading, setLocation]);

  // Fetch connections
  const { data: connectionsData, isLoading: loadingConnections } = useQuery({
    queryKey: ["/api/connections"],
    enabled: !!user,
  });

  // Create connection mutation
  const createConnectionMutation = useMutation({
    mutationFn: async (connectionData: any) => {
      const res = await apiRequest("POST", "/api/connections", connectionData);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Solicitação enviada",
        description: "A solicitação de conexão foi enviada com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
      setDialogOpen(false);
      setEmail("");
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao enviar solicitação",
        description: error.message || "Tente novamente mais tarde",
        variant: "destructive",
      });
    }
  });

  // Update connection status mutation
  const updateConnectionStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const res = await apiRequest("PATCH", `/api/connections/${id}/status`, { status });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Status atualizado",
        description: "O status da conexão foi atualizado com sucesso.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/connections"] });
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao atualizar status",
        description: error.message || "Tente novamente mais tarde",
        variant: "destructive",
      });
    }
  });

  // Handle connection request submission
  const handleCreateConnection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    if (user?.userType === "owner") {
      createConnectionMutation.mutate({ walkerId: email });
    } else {
      createConnectionMutation.mutate({ ownerId: email });
    }
  };

  // Handle connection status update
  const handleUpdateStatus = (id: number, status: string) => {
    updateConnectionStatusMutation.mutate({ id, status });
  };

  if (loading || !user) {
    return (
      <div className="p-4 flex justify-center items-center min-h-screen">
        <p>Carregando...</p>
      </div>
    );
  }

  // Sort connections into pending, accepted, and rejected
  const pendingConnections = connectionsData?.connections?.filter((conn: any) => 
    conn.status === "pending"
  ) || [];
  
  const acceptedConnections = connectionsData?.connections?.filter((conn: any) => 
    conn.status === "accepted"
  ) || [];
  
  const rejectedConnections = connectionsData?.connections?.filter((conn: any) => 
    conn.status === "rejected"
  ) || [];

  return (
    <section className="p-4 pb-20 md:pb-4 flex-1 overflow-auto">
      <header className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-1">Conexões</h1>
          <p className="text-gray-500">
            {user.userType === "owner" 
              ? "Gerencie suas conexões com passeadores" 
              : "Gerencie suas conexões com donos de cachorros"}
          </p>
        </div>
        
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center">
              <UserPlus className="h-4 w-4 mr-2" /> 
              Nova conexão
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Nova conexão</DialogTitle>
              <DialogDescription>
                {user.userType === "owner" 
                  ? "Conecte-se com um passeador utilizando o email de cadastro dele."
                  : "Conecte-se com um dono de cachorro utilizando o email de cadastro dele."}
              </DialogDescription>
            </DialogHeader>
            <form onSubmit={handleCreateConnection}>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="email@exemplo.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="col-span-3"
                    required
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createConnectionMutation.isPending}>
                  {createConnectionMutation.isPending 
                    ? "Enviando..." 
                    : "Enviar solicitação"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </header>
      
      <Tabs defaultValue="active" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="active">Ativas</TabsTrigger>
          <TabsTrigger value="pending">Pendentes</TabsTrigger>
          <TabsTrigger value="rejected">Rejeitadas</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="space-y-4">
          {loadingConnections ? (
            <div className="flex justify-center items-center p-12">
              <p className="text-gray-500">Carregando...</p>
            </div>
          ) : acceptedConnections.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {acceptedConnections.map((connection: any) => {
                const otherUser = user.userType === "owner" ? connection.walker : connection.owner;
                
                return (
                  <Card key={connection.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <UserCheck className="h-5 w-5 mr-2 text-green-500" />
                        Conexão ativa
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4">
                        <AvatarWithFallback
                          src={otherUser?.photo}
                          fallback={otherUser?.name || "?"}
                          className="w-12 h-12"
                        />
                        <div>
                          <h3 className="font-semibold">{otherUser?.name}</h3>
                          <p className="text-sm text-gray-500">
                            {user.userType === "owner" ? "Passeador" : "Dono de cachorro"}
                          </p>
                        </div>
                      </div>
                      
                      <div className="mt-4 flex items-center text-sm">
                        <Mail className="h-4 w-4 mr-1 text-gray-400" />
                        <span className="text-gray-500">{otherUser?.email}</span>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t pt-4 flex justify-between">
                      <span className="text-sm text-gray-500">
                        Conexão desde {new Date(connection.createdAt).toLocaleDateString()}
                      </span>
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center p-12">
              <div className="mb-4 text-gray-400">
                <Users className="h-16 w-16 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhuma conexão ativa
              </h3>
              <p className="text-gray-500 mb-6 max-w-md mx-auto">
                {user.userType === "owner"
                  ? "Conecte-se com passeadores para começar a agendar passeios para seus cachorros"
                  : "Conecte-se com donos de cachorros para começar a oferecer seus serviços de passeio"}
              </p>
              <Button onClick={() => setDialogOpen(true)}>
                <UserPlus className="h-4 w-4 mr-2" /> Nova conexão
              </Button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="pending" className="space-y-4">
          {loadingConnections ? (
            <div className="flex justify-center items-center p-12">
              <p className="text-gray-500">Carregando...</p>
            </div>
          ) : pendingConnections.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {pendingConnections.map((connection: any) => {
                const otherUser = user.userType === "owner" ? connection.walker : connection.owner;
                const isPendingFromMe = 
                  (user.userType === "owner" && connection.ownerId === user.id) ||
                  (user.userType === "walker" && connection.walkerId === user.id);
                
                return (
                  <Card key={connection.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <UserPlus className="h-5 w-5 mr-2 text-amber-500" />
                        {isPendingFromMe ? "Solicitação enviada" : "Solicitação recebida"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4">
                        <AvatarWithFallback
                          src={otherUser?.photo}
                          fallback={otherUser?.name || "?"}
                          className="w-12 h-12"
                        />
                        <div>
                          <h3 className="font-semibold">{otherUser?.name}</h3>
                          <p className="text-sm text-gray-500">
                            {user.userType === "owner" ? "Passeador" : "Dono de cachorro"}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t pt-4 flex justify-end">
                      {isPendingFromMe ? (
                        <span className="text-sm text-gray-500">Aguardando resposta</span>
                      ) : (
                        <div className="space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleUpdateStatus(connection.id, "rejected")}
                            disabled={updateConnectionStatusMutation.isPending}
                          >
                            <X className="h-4 w-4 mr-1" /> Recusar
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => handleUpdateStatus(connection.id, "accepted")}
                            disabled={updateConnectionStatusMutation.isPending}
                          >
                            <Check className="h-4 w-4 mr-1" /> Aceitar
                          </Button>
                        </div>
                      )}
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center p-12">
              <h3 className="text-lg font-medium text-gray-900">
                Nenhuma solicitação pendente
              </h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Você não possui solicitações de conexão pendentes
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="rejected" className="space-y-4">
          {loadingConnections ? (
            <div className="flex justify-center items-center p-12">
              <p className="text-gray-500">Carregando...</p>
            </div>
          ) : rejectedConnections.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {rejectedConnections.map((connection: any) => {
                const otherUser = user.userType === "owner" ? connection.walker : connection.owner;
                const wasRejectedByMe = 
                  (user.userType === "owner" && connection.walkerId === user.id) ||
                  (user.userType === "walker" && connection.ownerId === user.id);
                
                return (
                  <Card key={connection.id} className="overflow-hidden">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center">
                        <X className="h-5 w-5 mr-2 text-red-500" />
                        {wasRejectedByMe ? "Conexão rejeitada por você" : "Conexão rejeitada"}
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex items-center space-x-4">
                        <AvatarWithFallback
                          src={otherUser?.photo}
                          fallback={otherUser?.name || "?"}
                          className="w-12 h-12"
                        />
                        <div>
                          <h3 className="font-semibold">{otherUser?.name}</h3>
                          <p className="text-sm text-gray-500">
                            {user.userType === "owner" ? "Passeador" : "Dono de cachorro"}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="border-t pt-4 flex justify-end">
                      <Button
                        size="sm"
                        onClick={() => {
                          // Re-send connection request
                          if (user.userType === "owner") {
                            createConnectionMutation.mutate({ walkerId: otherUser.id });
                          } else {
                            createConnectionMutation.mutate({ ownerId: otherUser.id });
                          }
                        }}
                        disabled={createConnectionMutation.isPending}
                      >
                        <UserPlus className="h-4 w-4 mr-1" /> Tentar novamente
                      </Button>
                    </CardFooter>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center p-12">
              <h3 className="text-lg font-medium text-gray-900">
                Nenhuma conexão rejeitada
              </h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Você não possui conexões rejeitadas
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </section>
  );
}
