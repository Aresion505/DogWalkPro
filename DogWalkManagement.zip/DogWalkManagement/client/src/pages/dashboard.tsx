import { useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { Activity, Dog, Clock, Plus } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { StatCard } from "@/components/stat-card";
import { WalkItem } from "@/components/walk-item";
import { ActivityItem } from "@/components/activity-item";
import { DogCard } from "@/components/dog-card";
import { WalkForm } from "@/components/walk-form";

export default function Dashboard() {
  const [_, setLocation] = useLocation();
  const { user, loading } = useAuth();

  // Redirect to login if no user
  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    }
  }, [user, loading, setLocation]);

  // Fetch stats for walker
  const { data: statsData } = useQuery({
    queryKey: ["/api/walker/stats"],
    enabled: !!user && user.userType === "walker",
  });

  // Fetch scheduled walks
  const { data: scheduledWalksData } = useQuery({
    queryKey: ["/api/walks/scheduled"],
    enabled: !!user,
  });

  // Fetch activity feed for walker
  const { data: activityData } = useQuery({
    queryKey: ["/api/walker/activity"],
    enabled: !!user && user.userType === "walker",
  });

  // Fetch dogs
  const { data: dogsData } = useQuery({
    queryKey: ["/api/dogs"],
    enabled: !!user,
  });

  if (loading || !user) {
    return (
      <div className="p-4 flex justify-center items-center min-h-screen">
        <p>Carregando...</p>
      </div>
    );
  }

  return (
    <section className="p-4 pb-20 md:pb-4 flex-1 overflow-auto">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">Bem-vindo, {user.name.split(" ")[0]}!</h1>
        <p className="text-gray-500">Aqui está o resumo da sua atividade.</p>
      </header>
      
      {/* Stats Overview for walkers */}
      {user.userType === "walker" && statsData?.stats && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <StatCard
            title="Walks this month"
            value={statsData.stats.monthWalks}
            icon={Activity}
            iconColor="blue-600"
            changeText="12% a mais que o mês anterior"
            changeDirection="up"
          />
          
          <StatCard
            title="Active Dogs"
            value={statsData.stats.activeDogs}
            icon={Dog}
            iconColor="amber-500"
            changeText="2 new this month"
            changeDirection="up"
          />
          
          <StatCard
            title="Walk Hours"
            value={statsData.stats.walkHours}
            icon={Clock}
            iconColor="green-500"
            changeText="8 hours more than last month"
            changeDirection="up"
          />
        </div>
      )}
      
      {/* Next Walks Section */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-900">Upcoming Walks</h2>
          <Link href="/walks">
            <a className="text-blue-600 text-sm hover:underline">View All</a>
          </Link>
        </div>
        
        <Card className="shadow-sm overflow-hidden">
          {scheduledWalksData?.walks?.length > 0 ? (
            scheduledWalksData.walks.slice(0, 3).map((walk: any) => (
              <WalkItem key={walk.id} walk={walk} />
            ))
          ) : (
            <div className="p-8 text-center">
              <p className="text-gray-500 mb-4">No scheduled walks</p>
              {user.userType === "walker" ? (
                <Button 
                  variant="outline" 
                  onClick={() => document.getElementById("register-walk-btn")?.click()}
                >
                  <Plus className="h-4 w-4 mr-2" /> Register walk
                </Button>
              ) : (
                <Button variant="outline" asChild>
                  <Link href="/connections">
                    <a>Connect with walkers</a>
                  </Link>
                </Button>
              )}
            </div>
          )}
        </Card>
      </div>
      
      {/* Recent Activity + Dogs Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Activity Section */}
        {user.userType === "walker" && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Recent Activity</h2>
              <Link href="/walks">
                <a className="text-blue-600 text-sm hover:underline">View History</a>
              </Link>
            </div>
            
            <Card className="shadow-sm overflow-hidden">
              {activityData?.activities?.length > 0 ? (
                activityData.activities.slice(0, 3).map((activity: any, index: number) => (
                  <ActivityItem
                    key={`${activity.type}-${index}`}
                    type={activity.type}
                    data={activity.data}
                    createdAt={activity.createdAt}
                  />
                ))
              ) : (
                <div className="p-8 text-center text-gray-500">
                  No recent activity
                </div>
              )}
            </Card>
          </div>
        )}
        
        {/* My Dogs Section */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900">
              {user.userType === "owner" ? "My Dogs" : "Dogs"}
            </h2>
            <Link href="/dogs">
              <a className="text-blue-600 text-sm hover:underline">View All</a>
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {dogsData?.dogs?.slice(0, 3).map((dog: any) => (
              <DogCard key={dog.id} dog={dog} walkCount={dog.walkCount || 0} />
            ))}
            
            {user.userType === "owner" && (
              <Card className="border-2 border-dashed border-gray-300 flex flex-col items-center justify-center p-4 h-48">
                <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-500 mb-2">
                  <Plus className="h-6 w-6" />
                </div>
                <Link href="/dogs/add">
                  <a className="text-gray-500 text-center hover:text-gray-700">
                    Add new dog
                  </a>
                </Link>
              </Card>
            )}
          </div>
        </div>
      </div>
      
      {/* Register Walk Button and Form (for walkers only) */}
      {user.userType === "walker" && <WalkForm />}
    </section>
  );
}
