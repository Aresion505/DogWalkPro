import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/context/auth-context";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, startOfMonth, endOfMonth, subMonths, parseISO } from "date-fns";
import { ptBR, enUS } from "date-fns/locale";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { 
  Form, 
  FormControl, 
  FormDescription, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Table, 
  TableBody, 
  TableCaption, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Calendar,
  DollarSign, 
  ArrowDownRight, 
  ArrowUpRight, 
  PlusCircle,
  Wallet,
  Dog,
  Clock,
  Users,
  PieChart,
  PawPrint
} from "lucide-react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

// Schema para definir a taxa de passeio
const walkRateSchema = z.object({
  standardRate: z.string().min(1, "A taxa é obrigatória").refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: "A taxa deve ser um número positivo",
  }),
});

// Schema para adicionar créditos
const creditSchema = z.object({
  dogId: z.string().min(1, "Selecione um cachorro"),
  amount: z.string().min(1, "Informe a quantidade de créditos").refine(val => !isNaN(Number(val)) && Number(val) > 0, {
    message: "A quantidade deve ser um número positivo",
  }),
  description: z.string().min(3, "Descrição é obrigatória"),
});

export default function FinanceIndex() {
  const [_, setLocation] = useLocation();
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [period, setPeriod] = useState("current");
  const [showRateDialog, setShowRateDialog] = useState(false);
  const [showCreditsDialog, setShowCreditsDialog] = useState(false);

  // Redirecionamento para login se não houver usuário
  useEffect(() => {
    if (!loading && !user) {
      setLocation("/login");
    } else if (!loading && user && user.userType !== "walker") {
      // Somente dog walkers podem acessar esta página
      setLocation("/dashboard");
    }
  }, [user, loading, setLocation]);

  // Formulário para taxa padrão de passeio
  const rateForm = useForm({
    resolver: zodResolver(walkRateSchema),
    defaultValues: {
      standardRate: "30",
    },
  });

  // Formulário para adicionar créditos
  const creditForm = useForm({
    resolver: zodResolver(creditSchema),
    defaultValues: {
      dogId: "",
      amount: "",
      description: "Créditos para passeios",
    },
  });

  // Consulta estatísticas do walker
  const { data: statsData } = useQuery({
    queryKey: ["/api/walker/stats"],
    enabled: !!user && user.userType === "walker",
  });

  // Consultar passeios concluídos
  const { data: walksData, isLoading: loadingWalks } = useQuery({
    queryKey: ["/api/walks"],
    enabled: !!user && user.userType === "walker",
  });

  // Consultar conexões com cachorros
  const { data: dogsData, isLoading: loadingDogs } = useQuery({
    queryKey: ["/api/dogs"],
    enabled: !!user && user.userType === "walker",
  });

  // Mutação para salvar a taxa padrão
  const updateRateMutation = useMutation({
    mutationFn: async (data: { standardRate: number }) => {
      const res = await apiRequest("PATCH", "/api/walker/settings", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Taxa atualizada",
        description: "A taxa padrão de passeio foi atualizada com sucesso.",
      });
      
      // Recarregar dados relevantes
      queryClient.invalidateQueries({ queryKey: ["/api/walker/stats"] });
      setShowRateDialog(false);
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao atualizar taxa",
        description: error.message || "Tente novamente mais tarde",
        variant: "destructive",
      });
    },
  });

  // Mutação para adicionar créditos a um cachorro
  const addCreditMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", `/api/dogs/${data.dogId}/credit`, {
        amount: parseFloat(data.amount),
        description: data.description,
      });
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Créditos adicionados",
        description: "Os créditos foram adicionados com sucesso",
      });
      
      queryClient.invalidateQueries({ queryKey: ["/api/dogs"] });
      setShowCreditsDialog(false);
      creditForm.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Erro ao adicionar créditos",
        description: error.message || "Tente novamente mais tarde",
        variant: "destructive",
      });
    },
  });

  // Manipulador para enviar o formulário de taxa
  const onRateSubmit = (values: any) => {
    updateRateMutation.mutate({
      standardRate: parseFloat(values.standardRate),
    });
  };

  // Manipulador para enviar o formulário de créditos
  const onCreditSubmit = (values: any) => {
    addCreditMutation.mutate({
      dogId: parseInt(values.dogId),
      amount: values.amount,
      description: values.description,
    });
  };

  // Filtrar dados por período
  const getFilteredData = () => {
    if (!walksData?.walks || walksData.walks.length === 0) return [];
    
    const completedWalks = walksData.walks.filter((walk: any) => walk.status === "completed");
    let periodStart: Date;
    
    switch (period) {
      case "current":
        periodStart = startOfMonth(new Date());
        break;
      case "last":
        periodStart = startOfMonth(subMonths(new Date(), 1));
        break;
      case "last3":
        periodStart = startOfMonth(subMonths(new Date(), 3));
        break;
      case "all":
      default:
        return completedWalks;
    }
    
    return completedWalks.filter((walk: any) => {
      const walkDate = new Date(walk.date);
      return walkDate >= periodStart;
    });
  };

  // Calcular o faturamento total do período
  const calculateTotalRevenue = () => {
    const filteredWalks = getFilteredData();
    const standardRate = rateForm.getValues().standardRate ? parseFloat(rateForm.getValues().standardRate) : 30;
    
    return filteredWalks.reduce((total, walk: any) => {
      // Se o passeio tiver um custo definido, use-o. Caso contrário, use a taxa padrão
      const walkCost = walk.cost || standardRate;
      return total + walkCost;
    }, 0);
  };

  // Dados para o gráfico
  const getChartData = () => {
    if (!walksData?.walks) return [];
    
    // Agrupar passeios por mês nos últimos 6 meses
    const lastSixMonths = Array.from({ length: 6 }, (_, i) => {
      const date = subMonths(new Date(), i);
      return {
        month: format(date, "MMM", { locale: enUS }),
        year: format(date, "yyyy"),
        revenue: 0,
        walks: 0,
      };
    }).reverse();
    
    const completedWalks = walksData.walks.filter((walk: any) => walk.status === "completed");
    const standardRate = rateForm.getValues().standardRate ? parseFloat(rateForm.getValues().standardRate) : 30;
    
    completedWalks.forEach((walk: any) => {
      const walkDate = new Date(walk.date);
      const monthName = format(walkDate, "MMM", { locale: enUS });
      const yearName = format(walkDate, "yyyy");
      
      const monthIndex = lastSixMonths.findIndex(
        item => item.month === monthName && item.year === yearName
      );
      
      if (monthIndex >= 0) {
        lastSixMonths[monthIndex].walks += 1;
        lastSixMonths[monthIndex].revenue += (walk.cost || standardRate);
      }
    });
    
    return lastSixMonths.map(item => ({
      name: `${item.month}/${item.year.slice(2)}`,
      revenue: item.revenue,
      walks: item.walks,
    }));
  };

  if (loading || !user) {
    return (
      <div className="p-4 flex justify-center items-center min-h-screen">
        <p>Carregando...</p>
      </div>
    );
  }

  const totalRevenue = calculateTotalRevenue();
  const chartData = getChartData();
  const filteredWalks = getFilteredData();

  return (
    <section className="p-4 pb-20 md:pb-4 flex-1 overflow-auto">
      <header className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-1">Gestão Financeira</h1>
        <p className="text-gray-500">
          Administre suas finanças e créditos de passeios
        </p>
      </header>
      
      {/* Período de filtro */}
      <div className="mb-8 flex justify-between items-center">
        <div>
          <Select
            value={period}
            onValueChange={setPeriod}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Selecione o período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="current">Mês atual</SelectItem>
              <SelectItem value="last">Mês anterior</SelectItem>
              <SelectItem value="last3">Últimos 3 meses</SelectItem>
              <SelectItem value="all">Todo o período</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        {/* Botões de ações */}
        <div className="flex gap-2">
          <Dialog open={showRateDialog} onOpenChange={setShowRateDialog}>
            <DialogTrigger asChild>
              <Button variant="outline">
                <DollarSign className="h-4 w-4 mr-2" />
                Definir valor
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Definir valor de passeio</DialogTitle>
                <DialogDescription>
                  Configure o valor padrão para seus passeios
                </DialogDescription>
              </DialogHeader>
              
              <Form {...rateForm}>
                <form onSubmit={rateForm.handleSubmit(onRateSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={rateForm.control}
                    name="standardRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Valor padrão por passeio</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <DollarSign className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input 
                              type="number"
                              placeholder="0.00"
                              className="pl-8"
                              step="0.01"
                              min="0.01"
                              {...field}
                              disabled={updateRateMutation.isPending}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Este valor será usado como padrão para todos os passeios
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowRateDialog(false)}
                      disabled={updateRateMutation.isPending}
                    >
                      Cancelar
                    </Button>
                    <Button 
                      type="submit"
                      disabled={updateRateMutation.isPending}
                    >
                      {updateRateMutation.isPending ? "Salvando..." : "Salvar"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          <Dialog open={showCreditsDialog} onOpenChange={setShowCreditsDialog}>
            <DialogTrigger asChild>
              <Button variant="default">
                <PlusCircle className="h-4 w-4 mr-2" />
                Adicionar créditos
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Adicionar créditos</DialogTitle>
                <DialogDescription>
                  Adicione créditos para passeios de um cachorro
                </DialogDescription>
              </DialogHeader>
              
              <Form {...creditForm}>
                <form onSubmit={creditForm.handleSubmit(onCreditSubmit)} className="space-y-4 pt-4">
                  <FormField
                    control={creditForm.control}
                    name="dogId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Cachorro</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          disabled={loadingDogs || addCreditMutation.isPending}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Selecione um cachorro" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {dogsData?.dogs?.map((dog: any) => (
                              <SelectItem key={dog.id} value={dog.id.toString()}>
                                {dog.name} ({dog.breed})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={creditForm.control}
                    name="amount"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Quantidade de créditos</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <DollarSign className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                            <Input 
                              type="number"
                              placeholder="0.00"
                              className="pl-8"
                              step="0.5"
                              min="0.5"
                              {...field}
                              disabled={addCreditMutation.isPending}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Cada crédito equivale a um passeio (0.5 = meio passeio)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={creditForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Descrição</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Pacote de passeios, cuidados especiais, etc."
                            {...field}
                            disabled={addCreditMutation.isPending}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <DialogFooter>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setShowCreditsDialog(false)}
                      disabled={addCreditMutation.isPending}
                    >
                      Cancelar
                    </Button>
                    <Button 
                      type="submit"
                      disabled={addCreditMutation.isPending}
                    >
                      {addCreditMutation.isPending ? "Adicionando..." : "Adicionar créditos"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
      
      {/* Cards de estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <DollarSign className="h-8 w-8 text-primary" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Faturamento</p>
                <p className="text-2xl font-bold">${totalRevenue.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <PawPrint className="h-8 w-8 text-blue-500" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total de passeios</p>
                <p className="text-2xl font-bold">{filteredWalks.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-8 w-8 text-green-500" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Horas de passeio</p>
                <p className="text-2xl font-bold">{statsData?.stats?.walkHours || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Dog className="h-8 w-8 text-orange-500" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Cachorros ativos</p>
                <p className="text-2xl font-bold">{statsData?.stats?.activeDogs || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Gráfico de faturamento */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Faturamento e Passeios</CardTitle>
          <CardDescription>Análise de faturamento e número de passeios por mês</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                margin={{
                  top: 20,
                  right: 30,
                  left: 20,
                  bottom: 20,
                }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis yAxisId="left" orientation="left" stroke="#8884d8" />
                <YAxis yAxisId="right" orientation="right" stroke="#82ca9d" />
                <Tooltip formatter={(value, name) => {
                  if (name === "revenue") return [`$${value}`, "Faturamento"];
                  return [value, "Passeios"];
                }} />
                <Legend />
                <Bar yAxisId="left" dataKey="revenue" name="Faturamento" fill="#8884d8" />
                <Bar yAxisId="right" dataKey="walks" name="Passeios" fill="#82ca9d" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      
      {/* Tabela de passeios recentes */}
      <Card>
        <CardHeader>
          <CardTitle>Passeios Recentes</CardTitle>
          <CardDescription>
            Últimos passeios concluídos e suas informações financeiras
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredWalks.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Data</TableHead>
                    <TableHead>Cachorro</TableHead>
                    <TableHead>Duração</TableHead>
                    <TableHead>Valor</TableHead>
                    <TableHead>Créditos usados</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWalks.slice(0, 10).map((walk: any) => (
                    <TableRow key={walk.id}>
                      <TableCell>
                        <div className="font-medium">
                          {format(new Date(walk.date), "dd/MM/yyyy")}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {walk.formattedStartTime} - {walk.formattedEndTime}
                        </div>
                      </TableCell>
                      <TableCell>
                        {walk.dog?.name || "Cachorro não disponível"}
                      </TableCell>
                      <TableCell>{walk.duration}</TableCell>
                      <TableCell>
                        ${(walk.cost || rateForm.getValues().standardRate || 30).toFixed(2)}
                      </TableCell>
                      <TableCell>
                        {walk.chargedToDogCredit ? (
                          <span className="text-green-600 flex items-center">
                            <ArrowDownRight className="h-4 w-4 mr-1" /> Sim
                          </span>
                        ) : (
                          <span className="text-gray-500">Não</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center p-12">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Nenhum passeio no período selecionado
              </h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Selecione outro período ou registre novos passeios
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </section>
  );
}