import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { Link } from "wouter";

interface DogCardProps {
  dog: {
    id: number;
    name: string;
    breed: string;
    birthDate?: string;
    photo?: string;
  };
  walkCount?: number;
}

export function DogCard({ dog, walkCount = 0 }: DogCardProps) {
  // Calculate age if birthDate is available
  let ageText = "";
  if (dog.birthDate) {
    const birthDate = new Date(dog.birthDate);
    const now = new Date();
    const ageYears = now.getFullYear() - birthDate.getFullYear();
    
    if (ageYears < 1) {
      const ageMonths = now.getMonth() - birthDate.getMonth() + 
        (now.getFullYear() - birthDate.getFullYear()) * 12;
      ageText = `${ageMonths} ${ageMonths === 1 ? 'mês' : 'meses'}`;
    } else {
      ageText = `${ageYears} ${ageYears === 1 ? 'ano' : 'anos'}`;
    }
  }

  return (
    <Card className="overflow-hidden shadow-sm">
      <div className="h-32 bg-gray-100 relative">
        {dog.photo ? (
          <div
            className="w-full h-full bg-cover bg-center"
            style={{ backgroundImage: `url(${dog.photo})` }}
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-gray-400">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="w-16 h-16"
            >
              <path d="M10 5.172C10 3.12 12.507 2 14.444 2c1.938 0 3.556.988 3.556 3.348 0 1.777-1.325 3.464-2.74 5.089-.191.22-.379.435-.562.645-.947 1.086-1.798 2.063-1.798 2.727M4.684 15c-.664-1.618-.984-3.3-.984-5 0-2.21 1.817-4 4.096-4 1.72 0 3.395 2 3.774 4.145" />
              <path d="M21.048 14c.345.6.552 1.284.552 2 0 2.21-1.817 4-4.096 4s-4.096-1.79-4.096-4 1.817-4 4.096-4c.596 0 1.164.121 1.679.341" />
              <path d="M10.236 18c.346.6.553 1.284.553 2 0 2.21-1.848 4-4.127 4-2.28 0-4.127-1.79-4.127-4s1.848-4 4.127-4c.596 0 1.164.121 1.679.341" />
            </svg>
          </div>
        )}
      </div>
      <CardContent className="p-4">
        <h3 className="font-semibold text-lg text-gray-900">{dog.name}</h3>
        <p className="text-gray-500 text-sm">
          {dog.breed}{ageText ? `, ${ageText}` : ""}
        </p>
        <div className="mt-3 flex justify-between items-center">
          <span className="text-sm bg-blue-50 text-blue-600 py-1 px-2 rounded">
            {walkCount} {walkCount === 1 ? 'passeio' : 'passeios'}
          </span>
          <Link href={`/dogs/${dog.id}`}>
            <a className="text-blue-600 hover:text-blue-700 transition">
              <ArrowRight className="h-5 w-5" />
            </a>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
