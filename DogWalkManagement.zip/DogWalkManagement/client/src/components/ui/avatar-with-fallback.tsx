import { AvatarProps, Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "lucide-react";

interface AvatarWithFallbackProps extends AvatarProps {
  src?: string | null;
  fallback: string;
  alt?: string;
}

export function AvatarWithFallback({
  src,
  fallback,
  alt,
  ...props
}: AvatarWithFallbackProps) {
  const initials = fallback
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <Avatar {...props}>
      {src ? <AvatarImage src={src} alt={alt || fallback} /> : null}
      <AvatarFallback className="bg-primary text-primary-foreground">
        {initials || <User className="h-4 w-4" />}
      </AvatarFallback>
    </Avatar>
  );
}
