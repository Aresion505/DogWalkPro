import { format } from "date-fns";
import { AvatarWithFallback } from "@/components/ui/avatar-with-fallback";

interface WalkItemProps {
  walk: {
    id: number;
    date: string;
    startTime: string;
    endTime: string;
    duration: string;
    status: "scheduled" | "completed" | "cancelled";
    formattedDate?: string;
    formattedStartTime?: string;
    formattedEndTime?: string;
    dog?: {
      id: number;
      name: string;
      breed: string;
      photo?: string;
    };
  };
}

export function WalkItem({ walk }: WalkItemProps) {
  // Format date and time if not already formatted from API
  const displayDate = walk.formattedDate || format(new Date(walk.date), "PPP");
  const displayTime = (walk.formattedStartTime && walk.formattedEndTime) 
    ? `${walk.formattedStartTime} - ${walk.formattedEndTime}`
    : `${format(new Date(walk.startTime), "HH:mm")} - ${format(new Date(walk.endTime), "HH:mm")}`;

  return (
    <div className="p-4 border-b flex items-center justify-between">
      <div className="flex items-center space-x-3">
        <AvatarWithFallback
          src={walk.dog?.photo}
          fallback={walk.dog?.name || "?"}
          className="w-10 h-10"
        />
        <div>
          <p className="font-medium text-gray-900">{walk.dog?.name}</p>
          <p className="text-sm text-gray-500">{walk.dog?.breed}</p>
        </div>
      </div>
      <div className="text-right">
        <p className="font-medium text-gray-900">{displayDate}</p>
        <p className="text-sm text-gray-500">{walk.duration}</p>
      </div>
    </div>
  );
}
