import { format, formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Activity, UserPlus, MessageSquare } from "lucide-react";
import { AvatarWithFallback } from "@/components/ui/avatar-with-fallback";

interface ActivityItemProps {
  type: "walk" | "connection" | "feedback";
  data: any;
  createdAt: string | Date;
}

export function ActivityItem({ type, data, createdAt }: ActivityItemProps) {
  const date = typeof createdAt === "string" ? new Date(createdAt) : createdAt;
  const formattedDate = formatDistanceToNow(date, { 
    addSuffix: true,
    locale: ptBR
  });

  const renderIcon = () => {
    switch (type) {
      case "walk":
        return (
          <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
            <Activity className="h-5 w-5" />
          </div>
        );
      case "connection":
        return (
          <div className="w-10 h-10 rounded-full bg-amber-100 flex items-center justify-center text-amber-600">
            <UserPlus className="h-5 w-5" />
          </div>
        );
      case "feedback":
        return (
          <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
            <MessageSquare className="h-5 w-5" />
          </div>
        );
      default:
        return null;
    }
  };

  const renderContent = () => {
    switch (type) {
      case "walk":
        return (
          <>
            <p className="font-medium text-gray-900">
              Passeio concluído com <span className="font-semibold">{data.dog?.name}</span>
            </p>
            <p className="text-sm text-gray-500 mt-1">
              {format(new Date(data.startTime), "dd/MM/yyyy, HH:mm")} - {format(new Date(data.endTime), "HH:mm")}
            </p>
            {data.notes && (
              <p className="text-sm text-gray-500 mt-2">{data.notes}</p>
            )}
          </>
        );
      case "connection":
        return (
          <>
            <p className="font-medium text-gray-900">
              Nova conexão com <span className="font-semibold">{data.owner?.name}</span>
            </p>
            <p className="text-sm text-gray-500 mt-1">{formattedDate}</p>
          </>
        );
      case "feedback":
        return (
          <>
            <p className="font-medium text-gray-900">
              Feedback de <span className="font-semibold">{data.owner?.name}</span>
            </p>
            <p className="text-sm text-gray-500 mt-1">{formattedDate}</p>
            <p className="text-sm text-gray-500 mt-2">{data.message}</p>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <div className="p-4 border-b">
      <div className="flex">
        <div className="mr-4 flex-shrink-0">
          {renderIcon()}
        </div>
        <div>
          {renderContent()}
        </div>
      </div>
    </div>
  );
}
