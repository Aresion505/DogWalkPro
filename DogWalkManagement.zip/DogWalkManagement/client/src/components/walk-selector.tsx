import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface WalkSelectorProps {
  value: number;
  onChange: (value: number) => void;
  disabled?: boolean;
}

/**
 * Componente de seleção de número de passeios com botões clicáveis
 */
export function WalkSelector({ value, onChange, disabled = false }: WalkSelectorProps) {
  const walkOptions = [0.5, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap gap-2">
        {walkOptions.map((option) => (
          <Button
            key={option}
            type="button"
            variant={value === option ? "default" : "outline"}
            size="sm"
            className={cn(
              "rounded-full h-10 w-10 p-0",
              value === option ? "ring-2 ring-primary ring-offset-2" : ""
            )}
            onClick={() => onChange(option)}
            disabled={disabled}
          >
            {option}
          </Button>
        ))}
      </div>
      
      <div className="flex items-center justify-between px-2">
        <span className="text-sm text-muted-foreground">
          {value === 0.5 ? "Meio passeio" : `${value} ${value === 1 ? "passeio" : "passeios"}`}
        </span>
        
        {value > 0 && (
          <Badge variant="outline" className="text-xs">
            Selecionado: {value}
          </Badge>
        )}
      </div>
    </div>
  );
}