import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { format, parse } from "date-fns";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/context/auth-context";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { WalkSelector } from "@/components/walk-selector";
import { X, Plus, DollarSign, CreditCard } from "lucide-react";

// Form schema
const walkFormSchema = z.object({
  dogId: z.string().min(1, "Por favor, selecione um cachorro"),
  date: z.string().min(1, "Por favor, informe a data do passeio"),
  startTime: z.string().min(1, "Por favor, informe o horário de início"),
  endTime: z.string().min(1, "Por favor, informe o horário de término"),
  walkCount: z.number().min(0.5, "Informe a quantidade de passeios"),
  useCredits: z.boolean().default(false),
  notes: z.string().optional(),
});

type WalkFormValues = z.infer<typeof walkFormSchema>;

export function WalkForm() {
  const [open, setOpen] = useState(false);
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query dogs for this walker
  const { data: dogsData, isLoading: loadingDogs } = useQuery({
    queryKey: ["/api/dogs"],
    enabled: !!user && user.userType === "walker",
  });

  // Form setup
  const form = useForm<WalkFormValues>({
    resolver: zodResolver(walkFormSchema),
    defaultValues: {
      dogId: "",
      date: format(new Date(), "yyyy-MM-dd"),
      startTime: "",
      endTime: "",
      walkCount: 1,
      useCredits: false,
      notes: "",
    },
  });

  // Walk creation mutation
  const createWalkMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/walks", data);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Walk registered successfully!",
        description: "The new walk has been added to your calendar.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/walks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/walks/scheduled"] });
      queryClient.invalidateQueries({ queryKey: ["/api/walker/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/walker/activity"] });
      setOpen(false);
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error registering walk",
        description: error.message || "Please try again later",
        variant: "destructive",
      });
    },
  });

  // Form submission
  const onSubmit = (values: WalkFormValues) => {
    if (!user) return;

    try {
      // Parse form values to API format
      const dateObj = parse(values.date, "yyyy-MM-dd", new Date());
      const startTimeObj = parse(values.startTime, "HH:mm", new Date());
      const endTimeObj = parse(values.endTime, "HH:mm", new Date());
      
      // Calcular texto de duração com base na quantidade de passeios
      // 0.5 = 30min, 1 = 1h, etc.
      const walkCount = values.walkCount;
      const durationHours = walkCount >= 1 ? walkCount : 0.5;
      const durationText = durationHours >= 1 
        ? `${durationHours} ${durationHours === 1 ? 'hora' : 'horas'}`
        : `30 minutos`;

      // Create startTime and endTime by combining date with times
      const startTime = new Date(
        dateObj.getFullYear(),
        dateObj.getMonth(),
        dateObj.getDate(),
        startTimeObj.getHours(),
        startTimeObj.getMinutes()
      );
      
      const endTime = new Date(
        dateObj.getFullYear(),
        dateObj.getMonth(),
        dateObj.getDate(),
        endTimeObj.getHours(),
        endTimeObj.getMinutes()
      );

      // Query para obter o saldo de créditos do cachorro se quiser usar créditos
      if (values.useCredits) {
        // Verificar se há saldo de créditos suficiente antes de registrar
        apiRequest("GET", `/api/dogs/${values.dogId}/credit/balance`)
          .then(res => res.json())
          .then(data => {
            if (data.balance < values.walkCount) {
              toast({
                title: "Saldo insuficiente",
                description: `Este cachorro tem apenas ${data.balance} créditos disponíveis, necessário: ${values.walkCount}`,
                variant: "destructive",
              });
              return;
            }
            
            // Se há saldo suficiente, registrar o passeio
            registerWalk(values, dateObj, startTime, endTime, durationText);
          })
          .catch(() => {
            toast({
              title: "Erro ao verificar saldo",
              description: "Não foi possível verificar o saldo de créditos",
              variant: "destructive",
            });
          });
      } else {
        // Se não quiser usar créditos, registrar o passeio normalmente
        registerWalk(values, dateObj, startTime, endTime, durationText);
      }
    } catch (error) {
      toast({
        title: "Erro ao processar formulário",
        description: "Verifique seus dados e tente novamente",
        variant: "destructive",
      });
    }
  };
  
  // Função auxiliar para registrar o passeio
  const registerWalk = (
    values: WalkFormValues, 
    dateObj: Date, 
    startTime: Date, 
    endTime: Date, 
    durationText: string
  ) => {
    createWalkMutation.mutate({
      dogId: parseInt(values.dogId),
      date: dateObj.toISOString(),
      startTime: startTime.toISOString(),
      endTime: endTime.toISOString(),
      duration: durationText,
      walkCount: values.walkCount,
      useCredits: values.useCredits,
      notes: values.notes || "",
    });
  };

  return (
    <>
      {/* Fixed button */}
      <div className="fixed bottom-20 md:bottom-8 right-8 z-10">
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button
              size="icon"
              className="h-14 w-14 rounded-full shadow-lg"
            >
              <Plus className="h-6 w-6" />
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Register Walk</DialogTitle>
            </DialogHeader>
            
            {/* Walk registration form */}
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                {/* Dog Selection */}
                <FormField
                  control={form.control}
                  name="dogId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dog</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        disabled={loadingDogs || createWalkMutation.isPending}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select a dog" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {dogsData?.dogs?.map((dog: any) => (
                            <SelectItem key={dog.id} value={dog.id.toString()}>
                              {dog.name} ({dog.breed})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Date */}
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input 
                          type="date" 
                          {...field} 
                          disabled={createWalkMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Time Range */}
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="startTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Start Time</FormLabel>
                        <FormControl>
                          <Input 
                            type="time" 
                            {...field} 
                            disabled={createWalkMutation.isPending}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="endTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>End Time</FormLabel>
                        <FormControl>
                          <Input 
                            type="time" 
                            {...field} 
                            disabled={createWalkMutation.isPending}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                {/* Quantidade de passeios */}
                <FormField
                  control={form.control}
                  name="walkCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Quantidade de passeios</FormLabel>
                      <FormControl>
                        <WalkSelector 
                          value={field.value}
                          onChange={field.onChange}
                          disabled={createWalkMutation.isPending}
                        />
                      </FormControl>
                      <FormDescription>
                        Selecione quantos passeios serão registrados
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Usar créditos */}
                <FormField
                  control={form.control}
                  name="useCredits"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          disabled={createWalkMutation.isPending}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel>
                          Usar créditos do cachorro
                        </FormLabel>
                        <FormDescription>
                          Descontar este passeio dos créditos disponíveis
                        </FormDescription>
                      </div>
                    </FormItem>
                  )}
                />
                
                {/* Notes */}
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea 
                          {...field} 
                          placeholder="How was the walk? Any important observations?"
                          rows={3}
                          disabled={createWalkMutation.isPending}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                {/* Buttons */}
                <div className="flex justify-end space-x-3 pt-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setOpen(false)}
                    disabled={createWalkMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button 
                    type="submit"
                    disabled={createWalkMutation.isPending}
                  >
                    {createWalkMutation.isPending ? "Registering..." : "Register Walk"}
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
