import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/context/auth-context";
import { AvatarWithFallback } from "@/components/ui/avatar-with-fallback";
import {
  Home,
  Dog,
  User,
  Settings,
  LogOut,
  Link as LinkIcon,
  Activity,
  DollarSign
} from "lucide-react";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  return (
    <aside className="hidden md:flex md:flex-col w-64 bg-white shadow-md">
      <div className="p-4 border-b">
        <div className="flex items-center space-x-3">
          <span className="text-amber-500 font-bold text-2xl">🐾</span>
          <h1 className="text-xl font-bold text-gray-900">DogWalkPro</h1>
        </div>
      </div>
      
      {/* User Profile Summary */}
      {user && (
        <div className="p-4 border-b">
          <div className="flex items-center space-x-3">
            <AvatarWithFallback
              src={user.photo}
              fallback={user.name}
              className="w-10 h-10"
            />
            <div>
              <p className="font-semibold text-gray-900">{user.name}</p>
              <p className="text-sm text-gray-500">
                {user.userType === "walker" ? "Passeador" : "Dono"}
              </p>
            </div>
          </div>
        </div>
      )}
      
      {/* Navigation */}
      <nav className="p-2 flex-1">
        <ul className="space-y-1">
          <li>
            <Link href="/">
              <a className={cn(
                "flex items-center space-x-3 p-3 rounded-lg text-gray-900 hover:bg-gray-100 transition",
                location === "/" && "bg-blue-100 text-blue-600 font-medium"
              )}>
                <Home className="h-5 w-5" />
                <span>Dashboard</span>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/dogs">
              <a className={cn(
                "flex items-center space-x-3 p-3 rounded-lg text-gray-900 hover:bg-gray-100 transition",
                location === "/dogs" && "bg-blue-100 text-blue-600 font-medium"
              )}>
                <Dog className="h-5 w-5" />
                <span>Dogs</span>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/walks">
              <a className={cn(
                "flex items-center space-x-3 p-3 rounded-lg text-gray-900 hover:bg-gray-100 transition",
                location === "/walks" && "bg-blue-100 text-blue-600 font-medium"
              )}>
                <Activity className="h-5 w-5" />
                <span>Walks</span>
              </a>
            </Link>
          </li>
          <li>
            <Link href="/connections">
              <a className={cn(
                "flex items-center space-x-3 p-3 rounded-lg text-gray-900 hover:bg-gray-100 transition",
                location === "/connections" && "bg-blue-100 text-blue-600 font-medium"
              )}>
                <LinkIcon className="h-5 w-5" />
                <span>Connections</span>
              </a>
            </Link>
          </li>
          {/* Mostrar link de finanças apenas para dog walkers */}
          {user?.userType === "walker" && (
            <li>
              <Link href="/finance">
                <a className={cn(
                  "flex items-center space-x-3 p-3 rounded-lg text-gray-900 hover:bg-gray-100 transition",
                  location === "/finance" && "bg-blue-100 text-blue-600 font-medium"
                )}>
                  <DollarSign className="h-5 w-5" />
                  <span>Finanças</span>
                </a>
              </Link>
            </li>
          )}
        </ul>
      </nav>
      
      {/* Settings */}
      <div className="p-4 border-t">
        <Link href="/profile">
          <a className={cn(
            "flex items-center space-x-3 p-2 rounded text-gray-900 hover:bg-gray-100 transition",
            location === "/profile" && "bg-blue-100 text-blue-600"
          )}>
            <User className="h-5 w-5" />
            <span>Profile</span>
          </a>
        </Link>
        <button 
          onClick={logout}
          className="flex items-center space-x-3 w-full text-left p-2 rounded text-gray-900 hover:bg-gray-100 transition"
        >
          <LogOut className="h-5 w-5" />
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
