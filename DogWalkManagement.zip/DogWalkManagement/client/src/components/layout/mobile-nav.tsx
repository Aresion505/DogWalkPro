import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Home, Dog, User, Activity } from "lucide-react";

export function MobileNav() {
  const [location] = useLocation();

  return (
    <nav className="md:hidden bg-white border-t py-2 px-4 fixed bottom-0 w-full z-10">
      <div className="flex justify-around">
        <Link href="/">
          <a className={cn(
            "flex flex-col items-center p-2",
            location === "/" ? "text-blue-600" : "text-gray-500"
          )}>
            <Home className="h-5 w-5" />
            <span className="text-xs mt-1">Dashboard</span>
          </a>
        </Link>
        <Link href="/dogs">
          <a className={cn(
            "flex flex-col items-center p-2",
            location === "/dogs" ? "text-blue-600" : "text-gray-500"
          )}>
            <Dog className="h-5 w-5" />
            <span className="text-xs mt-1">Dogs</span>
          </a>
        </Link>
        <Link href="/walks">
          <a className={cn(
            "flex flex-col items-center p-2",
            location === "/walks" ? "text-blue-600" : "text-gray-500"
          )}>
            <Activity className="h-5 w-5" />
            <span className="text-xs mt-1">Walks</span>
          </a>
        </Link>
        <Link href="/profile">
          <a className={cn(
            "flex flex-col items-center p-2",
            location === "/profile" ? "text-blue-600" : "text-gray-500"
          )}>
            <User className="h-5 w-5" />
            <span className="text-xs mt-1">Profile</span>
          </a>
        </Link>
      </div>
    </nav>
  );
}
