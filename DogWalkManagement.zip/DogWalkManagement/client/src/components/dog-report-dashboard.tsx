import React, { useState } from "react";
import { format, parseISO } from "date-fns";
import { enUS } from "date-fns/locale";
import {
  BarChart,
  LineChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Calendar,
  CalendarDays,
  Clock,
  Download,
  FileText,
  MapPin,
  PawPrint,
  Activity,
  Heart,
  Flame,
  BarChart3,
  LineChart as LineChartIcon,
  PieChart as PieChartIcon,
} from "lucide-react";

// Utils for report data
function calculateAverageDuration(walks: any[]) {
  if (!walks || walks.length === 0) return "0 min";
  
  const totalMinutes = walks.reduce((total, walk) => {
    // Assuming duration is in format "X min" or "X hrs Y min"
    const durationStr = walk.duration;
    let minutes = 0;
    
    if (durationStr.includes("hrs")) {
      const [hoursStr, minutesStr] = durationStr.split(" hrs ");
      const hours = parseInt(hoursStr);
      const mins = parseInt(minutesStr);
      minutes = hours * 60 + mins;
    } else {
      minutes = parseInt(durationStr);
    }
    
    return total + (isNaN(minutes) ? 0 : minutes);
  }, 0);
  
  const average = Math.round(totalMinutes / walks.length);
  
  if (average >= 60) {
    const hours = Math.floor(average / 60);
    const mins = average % 60;
    return `${hours} hr${hours > 1 ? "s" : ""} ${mins} min`;
  }
  
  return `${average} min`;
}

function getMonthlyWalkCount(walks: any[], months = 6) {
  const today = new Date();
  const data = [];
  
  // Create an array of the last X months
  for (let i = 0; i < months; i++) {
    const monthDate = new Date(today.getFullYear(), today.getMonth() - i, 1);
    data.unshift({
      month: format(monthDate, "MMM yyyy"),
      count: 0,
      duration: 0,
    });
  }
  
  // Count walks per month
  walks.forEach(walk => {
    const walkDate = new Date(walk.date);
    const monthStr = format(walkDate, "MMM yyyy");
    const monthData = data.find(d => d.month === monthStr);
    
    if (monthData) {
      monthData.count += 1;
      
      // Add duration in minutes
      let durationMinutes = 0;
      const durationStr = walk.duration;
      
      if (durationStr.includes("hrs")) {
        const [hoursStr, minutesStr] = durationStr.split(" hrs ");
        const hours = parseInt(hoursStr);
        const mins = parseInt(minutesStr);
        durationMinutes = hours * 60 + mins;
      } else {
        durationMinutes = parseInt(durationStr);
      }
      
      monthData.duration += durationMinutes;
    }
  });
  
  return data;
}

function getBehaviorStats(walks: any[]) {
  const completedWalks = walks.filter(walk => walk.status === "completed");
  
  // Default behavior categories
  const categories = [
    { name: "Calm", count: 0 },
    { name: "Energetic", count: 0 },
    { name: "Friendly", count: 0 },
    { name: "Anxious", count: 0 },
    { name: "Stubborn", count: 0 },
  ];
  
  // Count behavior mentions
  completedWalks.forEach(walk => {
    if (!walk.behavior) return;
    
    const behaviorText = walk.behavior.toLowerCase();
    
    categories.forEach(category => {
      if (behaviorText.includes(category.name.toLowerCase())) {
        category.count += 1;
      }
    });
  });
  
  // Filter out empty categories
  return categories.filter(category => category.count > 0);
}

function getWalkDurationDistribution(walks: any[]) {
  const completedWalks = walks.filter(walk => walk.status === "completed");
  const distribution = [
    { name: "< 15 min", count: 0 },
    { name: "15-30 min", count: 0 },
    { name: "30-45 min", count: 0 },
    { name: "45-60 min", count: 0 },
    { name: "> 60 min", count: 0 },
  ];
  
  completedWalks.forEach(walk => {
    let durationMinutes = 0;
    const durationStr = walk.duration;
    
    if (durationStr.includes("hrs")) {
      const [hoursStr, minutesStr] = durationStr.split(" hrs ");
      const hours = parseInt(hoursStr);
      const mins = parseInt(minutesStr);
      durationMinutes = hours * 60 + mins;
    } else {
      durationMinutes = parseInt(durationStr);
    }
    
    if (durationMinutes < 15) {
      distribution[0].count += 1;
    } else if (durationMinutes < 30) {
      distribution[1].count += 1;
    } else if (durationMinutes < 45) {
      distribution[2].count += 1;
    } else if (durationMinutes < 60) {
      distribution[3].count += 1;
    } else {
      distribution[4].count += 1;
    }
  });
  
  return distribution;
}

// Function to export data to CSV
function exportToCSV(walks: any[], dogName: string) {
  const completedWalks = walks.filter(walk => walk.status === "completed");
  
  // Create CSV header
  let csvContent = "Date,Start Time,End Time,Duration,Behavior,Health Notes,Walker Notes\n";
  
  // Add rows
  completedWalks.forEach(walk => {
    const date = format(new Date(walk.date), "yyyy-MM-dd");
    const startTime = walk.formattedStartTime || "";
    const endTime = walk.formattedEndTime || "";
    const duration = walk.duration || "";
    const behavior = (walk.behavior || "").replace(/,/g, ";"); // Replace commas to not break CSV
    const healthNotes = (walk.healthNotes || "").replace(/,/g, ";");
    const notes = (walk.notes || "").replace(/,/g, ";");
    
    csvContent += `${date},${startTime},${endTime},${duration},${behavior},${healthNotes},${notes}\n`;
  });
  
  // Create download link
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `${dogName}_walks_report.csv`);
  link.style.visibility = "hidden";
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Color constants for charts
const CHART_COLORS = [
  "#8884d8", "#82ca9d", "#ffc658", "#ff8042", "#0088fe", 
  "#00C49F", "#FFBB28", "#FF8042", "#a4de6c", "#d0ed57"
];

interface DogReportDashboardProps {
  dog: any;
  walks: any[];
}

export function DogReportDashboard({ dog, walks }: DogReportDashboardProps) {
  const { toast } = useToast();
  const [reportPeriod, setReportPeriod] = useState("all");
  const [chartType, setChartType] = useState("bar");
  
  // Filter walks based on period
  const filteredWalks = (() => {
    if (reportPeriod === "all") return walks.filter(walk => walk.status === "completed");
    
    const today = new Date();
    let startDate = new Date();
    
    if (reportPeriod === "week") {
      startDate.setDate(today.getDate() - 7);
    } else if (reportPeriod === "month") {
      startDate.setMonth(today.getMonth() - 1);
    } else if (reportPeriod === "sixMonths") {
      startDate.setMonth(today.getMonth() - 6);
    } else if (reportPeriod === "year") {
      startDate.setFullYear(today.getFullYear() - 1);
    }
    
    return walks.filter(
      walk => walk.status === "completed" && new Date(walk.date) >= startDate
    );
  })();
  
  const completedWalks = walks.filter(walk => walk.status === "completed");
  
  // Calculate metrics
  const totalWalks = filteredWalks.length;
  const walksWithReports = filteredWalks.filter(walk => walk.notes).length;
  const totalCreditsUsed = filteredWalks.filter(walk => walk.chargedToDogCredit).length;
  const averageDuration = calculateAverageDuration(filteredWalks);
  const monthlyData = getMonthlyWalkCount(completedWalks, 6);
  const behaviorStats = getBehaviorStats(completedWalks);
  const durationDistribution = getWalkDurationDistribution(completedWalks);

  // Handle export
  const handleExport = () => {
    try {
      exportToCSV(walks, dog.name);
      toast({
        title: "Report exported",
        description: `${dog.name}'s report has been exported to CSV`,
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "There was an error exporting the report",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{dog.name}'s Report Dashboard</h2>
        <div className="flex gap-2">
          <Select
            value={reportPeriod}
            onValueChange={setReportPeriod}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Report Period" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Time</SelectItem>
              <SelectItem value="week">Last Week</SelectItem>
              <SelectItem value="month">Last Month</SelectItem>
              <SelectItem value="sixMonths">Last 6 Months</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleExport} variant="outline" className="flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <PawPrint className="h-8 w-8 text-primary" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Walks</p>
                <p className="text-2xl font-bold">{totalWalks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Clock className="h-8 w-8 text-blue-500" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Average Duration</p>
                <p className="text-2xl font-bold">{averageDuration}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <FileText className="h-8 w-8 text-green-500" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Complete Reports</p>
                <p className="text-2xl font-bold">{walksWithReports} / {totalWalks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-2">
              <Activity className="h-8 w-8 text-orange-500" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Credits Used</p>
                <p className="text-2xl font-bold">{totalCreditsUsed}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Walk Activity */}
        <Card className="col-span-1">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle>Monthly Activity</CardTitle>
              <div className="flex space-x-1">
                <Button 
                  size="sm" 
                  variant={chartType === "bar" ? "default" : "outline"} 
                  className="h-8 w-8 p-0" 
                  onClick={() => setChartType("bar")}
                >
                  <BarChart3 className="h-4 w-4" />
                </Button>
                <Button 
                  size="sm" 
                  variant={chartType === "line" ? "default" : "outline"} 
                  className="h-8 w-8 p-0"
                  onClick={() => setChartType("line")}
                >
                  <LineChartIcon className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <CardDescription>Number of walks completed per month</CardDescription>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                {chartType === "bar" ? (
                  <BarChart
                    data={monthlyData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 30 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="month" 
                      angle={-45} 
                      textAnchor="end" 
                      height={70}
                      tick={{fontSize: 12}}
                    />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Bar dataKey="count" fill="#8884d8" name="Walks" />
                  </BarChart>
                ) : (
                  <LineChart
                    data={monthlyData}
                    margin={{ top: 5, right: 30, left: 20, bottom: 30 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="month" 
                      angle={-45} 
                      textAnchor="end" 
                      height={70}
                      tick={{fontSize: 12}}
                    />
                    <YAxis allowDecimals={false} />
                    <Tooltip />
                    <Line type="monotone" dataKey="count" stroke="#8884d8" name="Walks" />
                  </LineChart>
                )}
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Split Chart Area */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Behavior Distribution */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Behavior Patterns</CardTitle>
              <CardDescription>Recorded behavior traits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                {behaviorStats.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={behaviorStats}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="count"
                        nameKey="name"
                        label={({ name, percent }) => 
                          `${name}: ${(percent * 100).toFixed(0)}%`
                        }
                      >
                        {behaviorStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip formatter={(value) => [`${value} mentions`, "Count"]} />
                    </PieChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-muted-foreground">No behavior data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Walk Duration */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Walk Durations</CardTitle>
              <CardDescription>Distribution of walk times</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                {completedWalks.length > 0 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={durationDistribution}
                      margin={{ top: 5, right: 10, left: 10, bottom: 20 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="name" 
                        angle={-45} 
                        textAnchor="end" 
                        height={60}
                        tick={{fontSize: 10}}
                      />
                      <YAxis allowDecimals={false} />
                      <Tooltip />
                      <Bar dataKey="count" fill="#82ca9d" name="Walks" />
                    </BarChart>
                  </ResponsiveContainer>
                ) : (
                  <div className="h-full flex items-center justify-center">
                    <p className="text-muted-foreground">No walk data available</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Recent Reports Table */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Walk Reports</CardTitle>
          <CardDescription>
            Latest {filteredWalks.length > 10 ? "10" : filteredWalks.length} walk reports for {dog.name}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {filteredWalks.length > 0 ? (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Date</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Behavior</TableHead>
                    <TableHead>Health</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWalks
                    .slice(0, 10)
                    .map((walk) => (
                      <TableRow key={walk.id}>
                        <TableCell>
                          <div className="font-medium">
                            {format(new Date(walk.date), "MMM d, yyyy")}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            {walk.formattedStartTime} - {walk.formattedEndTime}
                          </div>
                        </TableCell>
                        <TableCell>{walk.duration}</TableCell>
                        <TableCell>
                          {walk.behavior ? (
                            <div className="max-w-[150px] truncate" title={walk.behavior}>
                              {walk.behavior}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-xs">No data</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {walk.healthNotes ? (
                            <div className="max-w-[150px] truncate" title={walk.healthNotes}>
                              {walk.healthNotes}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-xs">No data</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {walk.notes ? (
                            <div className="max-w-[200px] truncate" title={walk.notes}>
                              {walk.notes}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-xs">No report</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="py-6 text-center">
              <p className="text-muted-foreground">No walk reports available for this period</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}