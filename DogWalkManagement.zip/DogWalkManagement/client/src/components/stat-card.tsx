import { Card } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: number | string;
  icon: LucideIcon;
  iconColor: string;
  changeText?: string;
  changeDirection?: "up" | "down" | "neutral";
}

export function StatCard({
  title,
  value,
  icon: Icon,
  iconColor,
  changeText,
  changeDirection
}: StatCardProps) {
  return (
    <Card className="shadow-sm">
      <div className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-gray-500 text-sm mb-1">{title}</p>
            <h3 className="text-2xl font-bold text-gray-900">{value}</h3>
          </div>
          <span className={`text-${iconColor} text-xl`}>
            <Icon className="h-6 w-6" />
          </span>
        </div>
        
        {changeText && (
          <div className="mt-2 text-xs">
            <span className={cn(
              changeDirection === "up" && "text-green-600",
              changeDirection === "down" && "text-red-600",
              changeDirection === "neutral" && "text-gray-500"
            )}>
              {changeDirection === "up" && "↑ "}
              {changeDirection === "down" && "↓ "}
              {changeText}
            </span>
          </div>
        )}
      </div>
    </Card>
  );
}

function cn(...classes: any[]) {
  return classes.filter(Boolean).join(" ");
}
