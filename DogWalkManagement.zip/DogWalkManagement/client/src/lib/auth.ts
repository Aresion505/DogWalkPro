import { apiRequest } from "./queryClient";

export async function loginUser(email: string, password: string) {
  const res = await apiRequest("POST", "/api/auth/login", { email, password });
  return res.json();
}

export async function registerUser(userData: {
  name: string;
  email: string;
  password: string;
  userType: "owner" | "walker";
  phone?: string;
}) {
  const res = await apiRequest("POST", "/api/auth/register", userData);
  return res.json();
}

export async function logoutUser() {
  await apiRequest("POST", "/api/auth/logout");
}

export async function getCurrentUser() {
  try {
    const res = await apiRequest("GET", "/api/auth/me");
    const data = await res.json();
    return data.user;
  } catch (error) {
    return null;
  }
}
