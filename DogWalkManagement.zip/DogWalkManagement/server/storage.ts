import { 
  users, type User, type InsertUser,
  dogs, type Dog, type InsertDog,
  connections, type Connection, type InsertConnection,
  dogWalkerConnections, type DogWalkerConnection, type InsertDogWalkerConnection,
  walks, type Walk, type InsertWalk,
  dogCredits, type DogCredit, type InsertDogCredit
} from "@shared/schema";

export interface IStorage {
  // User Operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<InsertUser>): Promise<User | undefined>;
  
  // Dog Operations
  getDog(id: number): Promise<Dog | undefined>;
  getDogsByOwnerId(ownerId: number): Promise<Dog[]>;
  createDog(dog: InsertDog): Promise<Dog>;
  updateDog(id: number, dog: Partial<InsertDog>): Promise<Dog | undefined>;
  deleteDog(id: number): Promise<boolean>;
  
  // Connection Operations
  getConnection(id: number): Promise<Connection | undefined>;
  getConnectionByOwnerAndWalker(ownerId: number, walkerId: number): Promise<Connection | undefined>;
  getConnectionsByOwnerId(ownerId: number): Promise<Connection[]>;
  getConnectionsByWalkerId(walkerId: number): Promise<Connection[]>;
  createConnection(connection: InsertConnection): Promise<Connection>;
  updateConnectionStatus(id: number, status: "pending" | "accepted" | "rejected"): Promise<Connection | undefined>;
  
  // Dog Walker Connection Operations
  getDogWalkerConnection(id: number): Promise<DogWalkerConnection | undefined>;
  getDogWalkerConnectionsByDogId(dogId: number): Promise<DogWalkerConnection[]>;
  getDogWalkerConnectionsByWalkerId(walkerId: number): Promise<DogWalkerConnection[]>;
  createDogWalkerConnection(connection: InsertDogWalkerConnection): Promise<DogWalkerConnection>;
  updateDogWalkerConnectionStatus(id: number, status: "active" | "inactive"): Promise<DogWalkerConnection | undefined>;
  
  // Walk Operations
  getWalk(id: number): Promise<Walk | undefined>;
  getWalksByDogId(dogId: number): Promise<Walk[]>;
  getWalksByWalkerId(walkerId: number): Promise<Walk[]>;
  getScheduledWalksByWalkerId(walkerId: number): Promise<Walk[]>;
  getCompletedWalksByWalkerId(walkerId: number): Promise<Walk[]>;
  createWalk(walk: InsertWalk): Promise<Walk>;
  updateWalk(id: number, walk: Partial<InsertWalk>): Promise<Walk | undefined>;
  updateWalkStatus(id: number, status: "scheduled" | "completed" | "cancelled"): Promise<Walk | undefined>;
  updateWalkReport(id: number, report: { notes: string, behavior?: string, healthNotes?: string, photo?: string }): Promise<Walk | undefined>;
  deleteWalk(id: number): Promise<boolean>;
  
  // Dog Credit Operations
  getDogCreditsByDogId(dogId: number): Promise<DogCredit[]>;
  addDogCredit(credit: InsertDogCredit): Promise<DogCredit>;
  getDogCreditBalance(dogId: number): Promise<number>;
  useDogCredit(dogId: number, walkId: number, amount: number): Promise<boolean>;
  
  // Dashboard Data
  getWalkerStats(walkerId: number): Promise<{
    monthWalks: number;
    activeDogs: number;
    walkHours: number;
  }>;
  
  // Activity feed
  getRecentActivityForWalker(walkerId: number, limit?: number): Promise<Array<{
    type: "walk" | "connection" | "feedback",
    data: any,
    createdAt: Date
  }>>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private dogs: Map<number, Dog>;
  private connections: Map<number, Connection>;
  private dogWalkerConnections: Map<number, DogWalkerConnection>;
  private walks: Map<number, Walk>;
  private dogCredits: Map<number, DogCredit>;
  
  private userId: number;
  private dogId: number;
  private connectionId: number;
  private dogWalkerConnectionId: number;
  private walkId: number;
  private dogCreditId: number;
  
  constructor() {
    this.users = new Map();
    this.dogs = new Map();
    this.connections = new Map();
    this.dogWalkerConnections = new Map();
    this.walks = new Map();
    this.dogCredits = new Map();
    
    this.userId = 1;
    this.dogId = 1;
    this.connectionId = 1;
    this.dogWalkerConnectionId = 1;
    this.walkId = 1;
    this.dogCreditId = 1;
    
    // Add some seed data
    this.seedData();
  }
  
  private seedData() {
    // Seed walker
    const walker: User = {
      id: this.userId++,
      name: "Maria Moreira",
      email: "walker@example.com",
      password: "password",
      userType: "walker",
      phone: "123-456-7890",
      photo: undefined,
      createdAt: new Date()
    };
    this.users.set(walker.id, walker);
    
    // Seed owner
    const owner: User = {
      id: this.userId++,
      name: "Ana Silva",
      email: "owner@example.com",
      password: "password",
      userType: "owner",
      phone: "098-765-4321",
      photo: undefined,
      createdAt: new Date()
    };
    this.users.set(owner.id, owner);
    
    // Seed dogs
    const dog1: Dog = {
      id: this.dogId++,
      name: "Rex",
      breed: "Golden Retriever",
      birthDate: new Date("2020-01-15"),
      photo: undefined,
      notes: "Very friendly and loves to play fetch",
      ownerId: owner.id,
      createdAt: new Date()
    };
    this.dogs.set(dog1.id, dog1);
    
    const dog2: Dog = {
      id: this.dogId++,
      name: "Bolinha",
      breed: "Pug",
      birthDate: new Date("2021-06-10"),
      photo: undefined,
      notes: "Gets tired easily, needs shorter walks",
      ownerId: owner.id,
      createdAt: new Date()
    };
    this.dogs.set(dog2.id, dog2);
    
    // Seed connection
    const connection: Connection = {
      id: this.connectionId++,
      ownerId: owner.id,
      walkerId: walker.id,
      status: "accepted",
      createdAt: new Date(Date.now() - 86400000) // Yesterday
    };
    this.connections.set(connection.id, connection);
    
    // Seed dog walker connections
    const dwc1: DogWalkerConnection = {
      id: this.dogWalkerConnectionId++,
      dogId: dog1.id,
      walkerId: walker.id,
      connectionId: connection.id,
      status: "active",
      createdAt: new Date(Date.now() - 86400000)
    };
    this.dogWalkerConnections.set(dwc1.id, dwc1);
    
    const dwc2: DogWalkerConnection = {
      id: this.dogWalkerConnectionId++,
      dogId: dog2.id,
      walkerId: walker.id,
      connectionId: connection.id,
      status: "active",
      createdAt: new Date(Date.now() - 86400000)
    };
    this.dogWalkerConnections.set(dwc2.id, dwc2);
    
    // Seed walks
    // Past walk for Rex
    const walk1: Walk = {
      id: this.walkId++,
      dogId: dog1.id,
      walkerId: walker.id,
      date: new Date(Date.now() - 86400000),  // Yesterday
      startTime: new Date(Date.now() - 86400000 + 36000000),  // 10:00 AM yesterday
      endTime: new Date(Date.now() - 86400000 + 39600000),     // 11:00 AM yesterday
      duration: "1 hour",
      notes: "Rex was very energetic today!",
      photo: undefined,
      status: "completed",
      createdAt: new Date(Date.now() - 86400000)
    };
    this.walks.set(walk1.id, walk1);
    
    // Upcoming walk for Rex
    const walk2: Walk = {
      id: this.walkId++,
      dogId: dog1.id,
      walkerId: walker.id,
      date: new Date(Date.now() + 86400000),  // Tomorrow
      startTime: new Date(Date.now() + 86400000 + 36000000),  // 10:00 AM tomorrow
      endTime: new Date(Date.now() + 86400000 + 39600000),     // 11:00 AM tomorrow
      duration: "1 hour",
      notes: "",
      photo: undefined,
      status: "scheduled",
      createdAt: new Date()
    };
    this.walks.set(walk2.id, walk2);
    
    // Upcoming walk for Bolinha
    const walk3: Walk = {
      id: this.walkId++,
      dogId: dog2.id,
      walkerId: walker.id,
      date: new Date(Date.now() + 172800000),  // Day after tomorrow
      startTime: new Date(Date.now() + 172800000 + 32400000),  // 9:00 AM day after tomorrow
      endTime: new Date(Date.now() + 172800000 + 34200000),    // 9:30 AM day after tomorrow
      duration: "30 minutes",
      notes: "",
      photo: undefined,
      status: "scheduled",
      createdAt: new Date()
    };
    this.walks.set(walk3.id, walk3);
  }
  
  // User Operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }
  
  async createUser(user: InsertUser): Promise<User> {
    const id = this.userId++;
    const newUser: User = { ...user, id, createdAt: new Date() };
    this.users.set(id, newUser);
    return newUser;
  }
  
  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser: User = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Dog Operations
  async getDog(id: number): Promise<Dog | undefined> {
    return this.dogs.get(id);
  }
  
  async getDogsByOwnerId(ownerId: number): Promise<Dog[]> {
    return Array.from(this.dogs.values()).filter(dog => dog.ownerId === ownerId);
  }
  
  async createDog(dog: InsertDog): Promise<Dog> {
    const id = this.dogId++;
    const newDog: Dog = { ...dog, id, createdAt: new Date() };
    this.dogs.set(id, newDog);
    return newDog;
  }
  
  async updateDog(id: number, dogData: Partial<InsertDog>): Promise<Dog | undefined> {
    const dog = this.dogs.get(id);
    if (!dog) return undefined;
    
    const updatedDog: Dog = { ...dog, ...dogData };
    this.dogs.set(id, updatedDog);
    return updatedDog;
  }
  
  async deleteDog(id: number): Promise<boolean> {
    return this.dogs.delete(id);
  }
  
  // Connection Operations
  async getConnection(id: number): Promise<Connection | undefined> {
    return this.connections.get(id);
  }
  
  async getConnectionByOwnerAndWalker(ownerId: number, walkerId: number): Promise<Connection | undefined> {
    return Array.from(this.connections.values()).find(
      conn => conn.ownerId === ownerId && conn.walkerId === walkerId
    );
  }
  
  async getConnectionsByOwnerId(ownerId: number): Promise<Connection[]> {
    return Array.from(this.connections.values()).filter(
      conn => conn.ownerId === ownerId
    );
  }
  
  async getConnectionsByWalkerId(walkerId: number): Promise<Connection[]> {
    return Array.from(this.connections.values()).filter(
      conn => conn.walkerId === walkerId
    );
  }
  
  async createConnection(connection: InsertConnection): Promise<Connection> {
    const id = this.connectionId++;
    const newConnection: Connection = { 
      ...connection, 
      id, 
      status: "pending", 
      createdAt: new Date() 
    };
    this.connections.set(id, newConnection);
    return newConnection;
  }
  
  async updateConnectionStatus(id: number, status: "pending" | "accepted" | "rejected"): Promise<Connection | undefined> {
    const connection = this.connections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection: Connection = { ...connection, status };
    this.connections.set(id, updatedConnection);
    return updatedConnection;
  }
  
  // Dog Walker Connection Operations
  async getDogWalkerConnection(id: number): Promise<DogWalkerConnection | undefined> {
    return this.dogWalkerConnections.get(id);
  }
  
  async getDogWalkerConnectionsByDogId(dogId: number): Promise<DogWalkerConnection[]> {
    return Array.from(this.dogWalkerConnections.values()).filter(
      conn => conn.dogId === dogId
    );
  }
  
  async getDogWalkerConnectionsByWalkerId(walkerId: number): Promise<DogWalkerConnection[]> {
    return Array.from(this.dogWalkerConnections.values()).filter(
      conn => conn.walkerId === walkerId
    );
  }
  
  async createDogWalkerConnection(connection: InsertDogWalkerConnection): Promise<DogWalkerConnection> {
    const id = this.dogWalkerConnectionId++;
    const newConnection: DogWalkerConnection = { 
      ...connection, 
      id, 
      status: "active", 
      createdAt: new Date() 
    };
    this.dogWalkerConnections.set(id, newConnection);
    return newConnection;
  }
  
  async updateDogWalkerConnectionStatus(id: number, status: "active" | "inactive"): Promise<DogWalkerConnection | undefined> {
    const connection = this.dogWalkerConnections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection: DogWalkerConnection = { ...connection, status };
    this.dogWalkerConnections.set(id, updatedConnection);
    return updatedConnection;
  }
  
  // Walk Operations
  async getWalk(id: number): Promise<Walk | undefined> {
    return this.walks.get(id);
  }
  
  async getWalksByDogId(dogId: number): Promise<Walk[]> {
    return Array.from(this.walks.values()).filter(
      walk => walk.dogId === dogId
    );
  }
  
  async getWalksByWalkerId(walkerId: number): Promise<Walk[]> {
    return Array.from(this.walks.values()).filter(
      walk => walk.walkerId === walkerId
    );
  }
  
  async getScheduledWalksByWalkerId(walkerId: number): Promise<Walk[]> {
    return Array.from(this.walks.values()).filter(
      walk => walk.walkerId === walkerId && walk.status === "scheduled"
    ).sort((a, b) => a.date.getTime() - b.date.getTime());
  }
  
  async getCompletedWalksByWalkerId(walkerId: number): Promise<Walk[]> {
    return Array.from(this.walks.values()).filter(
      walk => walk.walkerId === walkerId && walk.status === "completed"
    ).sort((a, b) => b.date.getTime() - a.date.getTime());
  }
  
  async createWalk(walk: InsertWalk): Promise<Walk> {
    const id = this.walkId++;
    const newWalk: Walk = { 
      ...walk, 
      id, 
      status: "scheduled", 
      createdAt: new Date() 
    };
    this.walks.set(id, newWalk);
    return newWalk;
  }
  
  async updateWalk(id: number, walkData: Partial<InsertWalk>): Promise<Walk | undefined> {
    const walk = this.walks.get(id);
    if (!walk) return undefined;
    
    const updatedWalk: Walk = { ...walk, ...walkData };
    this.walks.set(id, updatedWalk);
    return updatedWalk;
  }
  
  async updateWalkStatus(id: number, status: "scheduled" | "completed" | "cancelled"): Promise<Walk | undefined> {
    const walk = this.walks.get(id);
    if (!walk) return undefined;
    
    const updatedWalk: Walk = { ...walk, status };
    this.walks.set(id, updatedWalk);
    return updatedWalk;
  }
  
  async deleteWalk(id: number): Promise<boolean> {
    return this.walks.delete(id);
  }
  
  async updateWalkReport(id: number, report: { notes: string, behavior?: string, healthNotes?: string, photo?: string }): Promise<Walk | undefined> {
    const walk = this.walks.get(id);
    if (!walk) return undefined;
    
    const updatedWalk: Walk = { 
      ...walk, 
      notes: report.notes,
      behavior: report.behavior || null,
      healthNotes: report.healthNotes || null,
      photo: report.photo || null
    };
    
    this.walks.set(id, updatedWalk);
    return updatedWalk;
  }
  
  // Dog Credit Operations
  async getDogCreditsByDogId(dogId: number): Promise<DogCredit[]> {
    return Array.from(this.dogCredits.values()).filter(
      credit => credit.dogId === dogId
    ).sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
  
  async addDogCredit(credit: InsertDogCredit): Promise<DogCredit> {
    const id = this.dogCreditId++;
    const newCredit: DogCredit = {
      ...credit,
      id,
      createdAt: new Date()
    };
    this.dogCredits.set(id, newCredit);
    
    // Update dog's credit balance
    const dog = this.dogs.get(credit.dogId);
    if (dog) {
      const currentBalance = dog.creditBalance || 0;
      this.dogs.set(dog.id, {
        ...dog,
        creditBalance: currentBalance + credit.amount
      });
    }
    
    return newCredit;
  }
  
  async getDogCreditBalance(dogId: number): Promise<number> {
    const dog = this.dogs.get(dogId);
    if (!dog) return 0;
    return dog.creditBalance || 0;
  }
  
  async useDogCredit(dogId: number, walkId: number, amount: number): Promise<boolean> {
    const dog = this.dogs.get(dogId);
    const walk = this.walks.get(walkId);
    
    if (!dog || !walk || (dog.creditBalance || 0) < amount) {
      return false;
    }
    
    // Deduct credits from dog's balance
    this.dogs.set(dog.id, {
      ...dog,
      creditBalance: (dog.creditBalance || 0) - amount,
      totalSpent: (dog.totalSpent || 0) + amount
    });
    
    // Mark walk as charged to dog credit
    this.walks.set(walk.id, {
      ...walk,
      cost: amount,
      chargedToDogCredit: true
    });
    
    // Create a negative credit entry to record the usage
    const id = this.dogCreditId++;
    const creditUsage: DogCredit = {
      id,
      dogId,
      amount: -amount,
      description: `Used for walk on ${walk.date.toLocaleDateString()}`,
      transactionType: "use",
      relatedWalkId: walkId,
      createdAt: new Date()
    };
    this.dogCredits.set(id, creditUsage);
    
    return true;
  }
  
  // Dashboard Data
  async getWalkerStats(walkerId: number): Promise<{
    monthWalks: number;
    activeDogs: number;
    walkHours: number;
  }> {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    
    // Get all walks for the current month
    const monthWalks = Array.from(this.walks.values()).filter(
      walk => walk.walkerId === walkerId && 
      walk.date >= startOfMonth &&
      walk.status === "completed"
    ).length;
    
    // Get all active dog connections
    const activeDogConnections = Array.from(this.dogWalkerConnections.values()).filter(
      conn => conn.walkerId === walkerId && conn.status === "active"
    );
    
    const activeDogs = new Set(activeDogConnections.map(conn => conn.dogId)).size;
    
    // Calculate total walk hours for the month
    const walkHours = Array.from(this.walks.values())
      .filter(walk => 
        walk.walkerId === walkerId && 
        walk.date >= startOfMonth &&
        walk.status === "completed"
      )
      .reduce((total, walk) => {
        // Extract hours from duration string (e.g., "1 hour", "30 minutes")
        const durationMatch = walk.duration.match(/(\d+(\.\d+)?)/);
        if (durationMatch) {
          const durationValue = parseFloat(durationMatch[1]);
          if (walk.duration.includes("hour")) {
            return total + durationValue;
          } else if (walk.duration.includes("minute")) {
            return total + (durationValue / 60);
          }
        }
        return total;
      }, 0);
    
    return {
      monthWalks,
      activeDogs,
      walkHours: Math.round(walkHours)
    };
  }
  
  // Activity feed
  async getRecentActivityForWalker(walkerId: number, limit: number = 10): Promise<Array<{
    type: "walk" | "connection" | "feedback",
    data: any,
    createdAt: Date
  }>> {
    const activities = [];
    
    // Get recent completed walks
    const recentWalks = Array.from(this.walks.values())
      .filter(walk => walk.walkerId === walkerId && walk.status === "completed")
      .map(walk => ({
        type: "walk" as const,
        data: {
          ...walk,
          dog: this.dogs.get(walk.dogId)
        },
        createdAt: walk.createdAt
      }));
    
    // Get recent connections
    const recentConnections = Array.from(this.connections.values())
      .filter(conn => conn.walkerId === walkerId && conn.status === "accepted")
      .map(conn => ({
        type: "connection" as const,
        data: {
          ...conn,
          owner: this.users.get(conn.ownerId)
        },
        createdAt: conn.createdAt
      }));
    
    // Combine and sort by date (most recent first)
    activities.push(...recentWalks, ...recentConnections);
    activities.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return activities.slice(0, limit);
  }
}

export const storage = new MemStorage();
