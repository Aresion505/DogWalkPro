import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, loginSchema, insertDogSchema, 
  insertConnectionSchema, insertDogWalkerConnectionSchema, 
  insertWalkSchema, insertDogCreditSchema
} from "@shared/schema";
import { format } from "date-fns";
import session from "express-session";
import MemoryStore from "memorystore";

// Session setup
const MemoryStoreSession = MemoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Configure sessions
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "dogwalkpro-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 86400000, // 1 day
      },
      store: new MemoryStoreSession({
        checkPeriod: 86400000, // 1 day
      }),
    })
  );

  // Authentication middleware
  const isAuthenticated = (req: Request, res: Response, next: any) => {
    if (req.session && req.session.user) {
      return next();
    }
    return res.status(401).json({ message: "Unauthorized" });
  };

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      
      const user = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      // Set user in session
      req.session.user = userWithoutPassword;
      
      return res.status(201).json({ user: userWithoutPassword });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(loginData.email);
      if (!user || user.password !== loginData.password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      // Set user in session
      req.session.user = userWithoutPassword;
      
      return res.json({ user: userWithoutPassword });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      return res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(req.session.user.id);
    if (!user) {
      req.session.destroy(() => {});
      return res.status(401).json({ message: "User not found" });
    }
    
    // Remove password from response
    const { password, ...userWithoutPassword } = user;
    
    return res.json({ user: userWithoutPassword });
  });

  // Dog routes
  app.get("/api/dogs", isAuthenticated, async (req, res) => {
    const userId = req.session.user!.id;
    const user = await storage.getUser(userId);
    
    let dogs = [];
    if (user?.userType === "owner") {
      // Get owner's dogs
      dogs = await storage.getDogsByOwnerId(userId);
    } else if (user?.userType === "walker") {
      // Get walker's connected dogs
      const connections = await storage.getDogWalkerConnectionsByWalkerId(userId);
      const dogIds = connections.map(conn => conn.dogId);
      dogs = await Promise.all(dogIds.map(id => storage.getDog(id)));
      dogs = dogs.filter(dog => dog !== undefined) as any;
    }
    
    return res.json({ dogs });
  });

  app.post("/api/dogs", isAuthenticated, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.user!.id);
      
      // Only owners can create dogs
      if (user?.userType !== "owner") {
        return res.status(403).json({ message: "Only dog owners can create dogs" });
      }
      
      const dogData = insertDogSchema.parse({
        ...req.body,
        ownerId: user.id
      });
      
      const dog = await storage.createDog(dogData);
      return res.status(201).json({ dog });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/dogs/:id", isAuthenticated, async (req, res) => {
    const dogId = parseInt(req.params.id);
    if (isNaN(dogId)) {
      return res.status(400).json({ message: "Invalid dog ID" });
    }
    
    const dog = await storage.getDog(dogId);
    if (!dog) {
      return res.status(404).json({ message: "Dog not found" });
    }
    
    // Check if user has access to this dog
    const userId = req.session.user!.id;
    const user = await storage.getUser(userId);
    
    if (user?.userType === "owner" && dog.ownerId !== userId) {
      return res.status(403).json({ message: "You don't have access to this dog" });
    } else if (user?.userType === "walker") {
      const connections = await storage.getDogWalkerConnectionsByWalkerId(userId);
      const hasDogAccess = connections.some(conn => conn.dogId === dogId && conn.status === "active");
      
      if (!hasDogAccess) {
        return res.status(403).json({ message: "You don't have access to this dog" });
      }
    }
    
    return res.json({ dog });
  });

  // Connection routes
  app.get("/api/connections", isAuthenticated, async (req, res) => {
    const userId = req.session.user!.id;
    const user = await storage.getUser(userId);
    
    let connections = [];
    if (user?.userType === "owner") {
      connections = await storage.getConnectionsByOwnerId(userId);
    } else if (user?.userType === "walker") {
      connections = await storage.getConnectionsByWalkerId(userId);
    }
    
    // Include user details for each connection
    const detailedConnections = await Promise.all(
      connections.map(async (conn) => {
        const owner = await storage.getUser(conn.ownerId);
        const walker = await storage.getUser(conn.walkerId);
        
        return {
          ...conn,
          owner: owner ? { id: owner.id, name: owner.name, email: owner.email, photo: owner.photo } : null,
          walker: walker ? { id: walker.id, name: walker.name, email: walker.email, photo: walker.photo } : null
        };
      })
    );
    
    return res.json({ connections: detailedConnections });
  });

  app.post("/api/connections", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      // Validate connection data based on user type
      let connectionData;
      if (user?.userType === "owner") {
        connectionData = insertConnectionSchema.parse({
          ...req.body,
          ownerId: userId
        });
      } else if (user?.userType === "walker") {
        connectionData = insertConnectionSchema.parse({
          ...req.body,
          walkerId: userId
        });
      } else {
        return res.status(400).json({ message: "Invalid user type" });
      }
      
      // Check if connection already exists
      const existingConnection = await storage.getConnectionByOwnerAndWalker(
        connectionData.ownerId,
        connectionData.walkerId
      );
      
      if (existingConnection) {
        return res.status(400).json({ message: "Connection already exists" });
      }
      
      const connection = await storage.createConnection(connectionData);
      return res.status(201).json({ connection });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/connections/:id/status", isAuthenticated, async (req, res) => {
    try {
      const connectionId = parseInt(req.params.id);
      if (isNaN(connectionId)) {
        return res.status(400).json({ message: "Invalid connection ID" });
      }
      
      const { status } = req.body;
      if (!status || !["pending", "accepted", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const connection = await storage.getConnection(connectionId);
      if (!connection) {
        return res.status(404).json({ message: "Connection not found" });
      }
      
      // Only the receiver of the connection request can update status
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      if (
        (user?.userType === "owner" && connection.walkerId !== userId) ||
        (user?.userType === "walker" && connection.ownerId !== userId)
      ) {
        return res.status(403).json({ message: "You cannot update this connection" });
      }
      
      const updatedConnection = await storage.updateConnectionStatus(connectionId, status as any);
      return res.json({ connection: updatedConnection });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  // Dog Walker Connection routes
  app.post("/api/dog-walker-connections", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      // Only owners can create dog-walker connections
      if (user?.userType !== "owner") {
        return res.status(403).json({ message: "Only dog owners can create dog-walker connections" });
      }
      
      const connectionData = insertDogWalkerConnectionSchema.parse(req.body);
      
      // Verify dog ownership
      const dog = await storage.getDog(connectionData.dogId);
      if (!dog || dog.ownerId !== userId) {
        return res.status(403).json({ message: "You don't own this dog" });
      }
      
      // Verify connection exists and is accepted
      const connection = await storage.getConnection(connectionData.connectionId);
      if (!connection || connection.ownerId !== userId || connection.status !== "accepted") {
        return res.status(400).json({ message: "Invalid or unaccepted connection" });
      }
      
      const dogWalkerConnection = await storage.createDogWalkerConnection(connectionData);
      return res.status(201).json({ connection: dogWalkerConnection });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  // Walk routes
  app.get("/api/walks", isAuthenticated, async (req, res) => {
    const userId = req.session.user!.id;
    const user = await storage.getUser(userId);
    
    let walks = [];
    if (user?.userType === "owner") {
      // Get walks for owner's dogs
      const dogs = await storage.getDogsByOwnerId(userId);
      walks = (await Promise.all(
        dogs.map(dog => storage.getWalksByDogId(dog.id))
      )).flat();
    } else if (user?.userType === "walker") {
      // Get walks for walker
      walks = await storage.getWalksByWalkerId(userId);
    }
    
    // Sort walks by date (most recent first)
    walks.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    // Include dog details for each walk
    const detailedWalks = await Promise.all(
      walks.map(async (walk) => {
        const dog = await storage.getDog(walk.dogId);
        const walker = await storage.getUser(walk.walkerId);
        
        return {
          ...walk,
          dog: dog ? { id: dog.id, name: dog.name, breed: dog.breed, photo: dog.photo } : null,
          walker: walker ? { id: walker.id, name: walker.name } : null,
          formattedDate: format(new Date(walk.date), "PPP"),
          formattedStartTime: format(new Date(walk.startTime), "p"),
          formattedEndTime: format(new Date(walk.endTime), "p")
        };
      })
    );
    
    return res.json({ walks: detailedWalks });
  });

  app.get("/api/walks/scheduled", isAuthenticated, async (req, res) => {
    const userId = req.session.user!.id;
    const user = await storage.getUser(userId);
    
    let walks = [];
    if (user?.userType === "walker") {
      walks = await storage.getScheduledWalksByWalkerId(userId);
    } else if (user?.userType === "owner") {
      // Get walks for owner's dogs
      const dogs = await storage.getDogsByOwnerId(userId);
      walks = (await Promise.all(
        dogs.map(async (dog) => {
          const dogWalks = await storage.getWalksByDogId(dog.id);
          return dogWalks.filter(walk => walk.status === "scheduled");
        })
      )).flat();
      
      // Sort by date
      walks.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    }
    
    // Include dog details for each walk
    const detailedWalks = await Promise.all(
      walks.map(async (walk) => {
        const dog = await storage.getDog(walk.dogId);
        
        return {
          ...walk,
          dog: dog ? { id: dog.id, name: dog.name, breed: dog.breed, photo: dog.photo } : null,
          formattedDate: format(new Date(walk.date), "PPP"),
          formattedStartTime: format(new Date(walk.startTime), "p"),
          formattedEndTime: format(new Date(walk.endTime), "p")
        };
      })
    );
    
    return res.json({ walks: detailedWalks });
  });

  app.post("/api/walks", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      // Only walkers can create walks
      if (user?.userType !== "walker") {
        return res.status(403).json({ message: "Only dog walkers can create walks" });
      }
      
      // Extrair valores adicionais dos dados brutos
      const { walkCount = 1, useCredits = false } = req.body;
      
      const walkData = insertWalkSchema.parse({
        ...req.body,
        walkerId: userId,
        // Garantir que o campo chargedToDogCredit seja atualizado com base no useCredits
        chargedToDogCredit: useCredits
      });
      
      // Verify dog-walker connection exists
      const dogConnections = await storage.getDogWalkerConnectionsByWalkerId(userId);
      const canWalkDog = dogConnections.some(
        conn => conn.dogId === walkData.dogId && conn.status === "active"
      );
      
      if (!canWalkDog) {
        return res.status(403).json({ message: "You don't have permission to walk this dog" });
      }
      
      // Se for usar créditos, verificar o saldo antes de criar o passeio
      if (useCredits) {
        const balance = await storage.getDogCreditBalance(walkData.dogId);
        if (balance < walkCount) {
          return res.status(400).json({ 
            message: `Insufficient credits. Available: ${balance}, Required: ${walkCount}` 
          });
        }
      }
      
      const walk = await storage.createWalk(walkData);
      
      // Se estiver usando créditos e o passeio foi criado com sucesso, descontar os créditos
      if (useCredits && walk) {
        await storage.useDogCredit(walkData.dogId, walk.id, walkCount);
      }
      
      // Return with formatted date
      const dog = await storage.getDog(walk.dogId);
      
      return res.status(201).json({ 
        walk: {
          ...walk,
          dog: dog ? { id: dog.id, name: dog.name, breed: dog.breed, photo: dog.photo } : null,
          formattedDate: format(new Date(walk.date), "PPP"),
          formattedStartTime: format(new Date(walk.startTime), "p"),
          formattedEndTime: format(new Date(walk.endTime), "p")
        } 
      });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  app.patch("/api/walks/:id/status", isAuthenticated, async (req, res) => {
    try {
      const walkId = parseInt(req.params.id);
      if (isNaN(walkId)) {
        return res.status(400).json({ message: "Invalid walk ID" });
      }
      
      const { status } = req.body;
      if (!status || !["scheduled", "completed", "cancelled"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }
      
      const walk = await storage.getWalk(walkId);
      if (!walk) {
        return res.status(404).json({ message: "Walk not found" });
      }
      
      // Only the walker can update walk status
      const userId = req.session.user!.id;
      if (walk.walkerId !== userId) {
        return res.status(403).json({ message: "You cannot update this walk" });
      }
      
      const updatedWalk = await storage.updateWalkStatus(walkId, status as any);
      return res.json({ walk: updatedWalk });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });
  
  // Walk Report routes
  app.patch("/api/walks/:id/report", isAuthenticated, async (req, res) => {
    try {
      const walkId = parseInt(req.params.id);
      if (isNaN(walkId)) {
        return res.status(400).json({ message: "Invalid walk ID" });
      }
      
      const { notes, behavior, healthNotes, photo } = req.body;
      if (!notes) {
        return res.status(400).json({ message: "Notes are required" });
      }
      
      const walk = await storage.getWalk(walkId);
      if (!walk) {
        return res.status(404).json({ message: "Walk not found" });
      }
      
      // Only the walker can update walk report
      const userId = req.session.user!.id;
      if (walk.walkerId !== userId) {
        return res.status(403).json({ message: "You cannot update this walk report" });
      }
      
      const updatedWalk = await storage.updateWalkReport(walkId, { 
        notes, 
        behavior, 
        healthNotes, 
        photo 
      });
      
      return res.json({ walk: updatedWalk });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });
  
  // Dog Credit routes
  app.get("/api/dogs/:id/credits", isAuthenticated, async (req, res) => {
    try {
      const dogId = parseInt(req.params.id);
      if (isNaN(dogId)) {
        return res.status(400).json({ message: "Invalid dog ID" });
      }
      
      const dog = await storage.getDog(dogId);
      if (!dog) {
        return res.status(404).json({ message: "Dog not found" });
      }
      
      // Check if user has access to this dog
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      if (user?.userType === "owner" && dog.ownerId !== userId) {
        return res.status(403).json({ message: "You don't have access to this dog" });
      } else if (user?.userType === "walker") {
        const connections = await storage.getDogWalkerConnectionsByWalkerId(userId);
        const hasDogAccess = connections.some(conn => conn.dogId === dogId && conn.status === "active");
        
        if (!hasDogAccess) {
          return res.status(403).json({ message: "You don't have access to this dog" });
        }
      }
      
      const credits = await storage.getDogCreditsByDogId(dogId);
      const balance = await storage.getDogCreditBalance(dogId);
      
      return res.json({ credits, balance });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });
  
  // Rota específica para verificar o saldo de créditos do cachorro
  app.get("/api/dogs/:id/credit/balance", isAuthenticated, async (req, res) => {
    try {
      const dogId = parseInt(req.params.id);
      if (isNaN(dogId)) {
        return res.status(400).json({ message: "Invalid dog ID" });
      }
      
      const dog = await storage.getDog(dogId);
      if (!dog) {
        return res.status(404).json({ message: "Dog not found" });
      }
      
      // Check if user has access to this dog
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      if (user?.userType === "owner" && dog.ownerId !== userId) {
        return res.status(403).json({ message: "You don't have access to this dog" });
      } else if (user?.userType === "walker") {
        const connections = await storage.getDogWalkerConnectionsByWalkerId(userId);
        const hasDogAccess = connections.some(conn => conn.dogId === dogId && conn.status === "active");
        
        if (!hasDogAccess) {
          return res.status(403).json({ message: "You don't have access to this dog" });
        }
      }
      
      const balance = await storage.getDogCreditBalance(dogId);
      
      return res.json({ balance });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });
  
  app.post("/api/dogs/:id/credits", isAuthenticated, async (req, res) => {
    try {
      const dogId = parseInt(req.params.id);
      if (isNaN(dogId)) {
        return res.status(400).json({ message: "Invalid dog ID" });
      }
      
      const dog = await storage.getDog(dogId);
      if (!dog) {
        return res.status(404).json({ message: "Dog not found" });
      }
      
      // Only the owner can add credits
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "owner" || dog.ownerId !== userId) {
        return res.status(403).json({ message: "Only the dog owner can add credits" });
      }
      
      const creditData = insertDogCreditSchema.parse({
        ...req.body,
        dogId,
        transactionType: "add"
      });
      
      const credit = await storage.addDogCredit(creditData);
      const balance = await storage.getDogCreditBalance(dogId);
      
      return res.status(201).json({ credit, balance });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });
  
  app.post("/api/walks/:id/charge-credit", isAuthenticated, async (req, res) => {
    try {
      const walkId = parseInt(req.params.id);
      if (isNaN(walkId)) {
        return res.status(400).json({ message: "Invalid walk ID" });
      }
      
      const { amount } = req.body;
      if (typeof amount !== "number" || amount <= 0) {
        return res.status(400).json({ message: "Valid amount is required" });
      }
      
      const walk = await storage.getWalk(walkId);
      if (!walk) {
        return res.status(404).json({ message: "Walk not found" });
      }
      
      // Only the walker can charge credits
      const userId = req.session.user!.id;
      if (walk.walkerId !== userId) {
        return res.status(403).json({ message: "You cannot charge credits for this walk" });
      }
      
      // Only completed walks can be charged
      if (walk.status !== "completed") {
        return res.status(400).json({ message: "Only completed walks can be charged" });
      }
      
      // Check if already charged
      if (walk.chargedToDogCredit) {
        return res.status(400).json({ message: "This walk has already been charged" });
      }
      
      const success = await storage.useDogCredit(walk.dogId, walkId, amount);
      
      if (!success) {
        return res.status(400).json({ message: "Insufficient credits" });
      }
      
      const updatedWalk = await storage.getWalk(walkId);
      return res.json({ success: true, walk: updatedWalk });
    } catch (error: any) {
      return res.status(400).json({ message: error.message });
    }
  });

  // Dashboard/stats routes
  app.get("/api/walker/stats", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "walker") {
        return res.status(403).json({ message: "Only dog walkers can access these stats" });
      }
      
      const stats = await storage.getWalkerStats(userId);
      return res.json({ stats });
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/walker/activity", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "walker") {
        return res.status(403).json({ message: "Only dog walkers can access activity feed" });
      }
      
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const activities = await storage.getRecentActivityForWalker(userId, limit);
      
      return res.json({ activities });
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  // Rota para atualizar as configurações do dog walker
  app.patch("/api/walker/settings", isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.user!.id;
      const user = await storage.getUser(userId);
      
      if (user?.userType !== "walker") {
        return res.status(403).json({ message: "Acesso apenas para dog walkers" });
      }
      
      const { standardRate } = req.body;
      if (typeof standardRate !== 'number' || standardRate <= 0) {
        return res.status(400).json({ message: "Taxa inválida" });
      }
      
      // Atualizar taxas e configurações
      const updatedUser = await storage.updateUser(userId, {
        // Aqui podemos adicionar mais configurações no futuro
        standardRate: standardRate
      });
      
      return res.json({ 
        settings: { 
          standardRate 
        } 
      });
    } catch (error: any) {
      return res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
